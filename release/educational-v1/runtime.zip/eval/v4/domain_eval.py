"""Self-contained v4 evaluation. CPU preflight; smoke first; no automatic release PASS.

v3 remains in eval/domain_eval.py for exact historical reproduction.
This is a new structured-output protocol, not a rescore of v3 generations.
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import importlib.metadata
import json
import math
import os
import re
import struct
import time
from collections import Counter
from contextlib import contextmanager
from pathlib import Path

BUNDLE_VERSION = "2026-08-31.v4.2"
FIXTURE_VERSION = "2026-08-31.v4.1"  # Frozen cases/targets, not the runtime protocol.
PROTOCOL = "llama31-native-chat-v4.2"
CHAT_TEMPLATE_SHA256 = (
    "e10ca381b1ccc5cf9db52e371f3b6651576caee0a630b452e2816b2d404d4b65"
)
CHAT_DATE = "31 Aug 2026"  # Fixed template metadata, not current legal guidance.
STOP_POLICY = "native-eos-or-invalid-continuation-v1"
CONTROL_TOKENS = {
    "<|begin_of_text|>": 128000,
    "<|end_of_text|>": 128001,
    "<|start_header_id|>": 128006,
    "<|end_header_id|>": 128007,
    "<|eom_id|>": 128008,
    "<|eot_id|>": 128009,
}
ANSWER_END_IDS = {128001, 128009}
GENERATION_STOP_IDS = {128001, 128008, 128009}
BASE_MODEL = "unsloth/meta-llama-3.1-8b-instruct-unsloth-bnb-4bit"
# Observed in the tokenizer cache retained with the completed v3 evaluation.
BASE_REVISION = "0db785ab56c082e30ae7dea3645d45465fbb5797"
LEGACY_SHA256 = "85edb481b4bbceeb0a1630830882e2f5c05cf5b1a664667678727526462a7fe8"
COUNTS = {"risk_assessment": 56, "classification": 200, "regulatory_identification": 26}
TIERS = {"LOW", "MEDIUM", "HIGH", "CRITICAL", "UNDETERMINED"}
PATTERNS = {
    "card_testing",
    "account_takeover",
    "bust_out",
    "structuring",
    "layering",
    "legitimate",
    "undetermined",
}
ACTIONS = {"restrict", "escalate", "no_action", "review"}
LIMITS = {
    "classification": 64,
    "risk_assessment": 384,
    "regulatory_identification": 512,
}
MAX_CONTEXT = 2048
PINS = {
    "transformers": "5.5.0",
    "datasets": "4.3.0",
    "trl": "0.24.0",
    "bitsandbytes": "0.50.1",
    "xformers": "0.0.34",
    "peft": "0.19.1",
    "unsloth": "2026.8.22",
    "unsloth_zoo": "2026.8.16",
}
RISK_INSTRUCTION = (
    "Analyse only the supplied facts. Return one JSON object, no markdown or extra text, "
    'with exactly these keys: "tier", "pattern", "action", "evidence", "rationale". '
    "tier must be LOW, MEDIUM, HIGH, CRITICAL or UNDETERMINED. pattern must be "
    "card_testing, account_takeover, bust_out, structuring, layering, legitimate or undetermined. "
    "action must be restrict, escalate, no_action or review. evidence must be an object "
    "containing at least two supplied field names with their exact string values. "
    "For fewer than two available fields, cite all available fields. rationale must be "
    "one to three concise sentences, grounded in those facts. Do not invent numerical "
    "scores, probabilities, history, time windows, devices, locations or counterparties. "
    "Amount is the current transaction amount, not the sum of TxnCount1h transactions. "
    "TxnCount1h covers one hour only; AccountHistoryMonths is account age, not activity history. "
    "A missing field is unknown, not evidence of absence. For contradictory facts or "
    "insufficient context use UNDETERMINED, undetermined, review and explain the limitation. "
    "Tiers are this benchmark's triage rubric, not legal findings: LOW is supported benign "
    "activity; MEDIUM is an isolated unresolved anomaly requiring verification; HIGH is "
    "a coherent suspicious pattern; CRITICAL is a severe converging pattern requiring urgent review. "
    "Distinguish a suspected pattern from proven intent."
)
CLASS_INSTRUCTION = "Classify the supplied transaction. Return exactly FRAUD or LEGITIMATE and nothing else."
REG_INSTRUCTION = (
    "Identify the controlling Bank Secrecy Act section for the question. Return a concise "
    "answer with exactly one citation in the form 31 CFR § part.section. If uncertain, "
    "say so rather than inventing a rule. Citation identification alone does not prove "
    "the legal accuracy of the explanation."
)
CITATION = re.compile(r"\b31\s+CFR\s*(?:§\s*)?(\d{4}\.\d{1,4})(?!\d)", re.I)


class PreflightError(ValueError):
    pass


class ProtocolError(RuntimeError):
    pass


def require(condition, message):
    if not condition:
        raise PreflightError(message)


def sha256(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def canonical_hash(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, allow_nan=False).encode()
    ).hexdigest()


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def strict_json(text):
    def invalid(value):
        raise ValueError(f"Non-finite JSON value: {value}")

    return json.loads(text, object_pairs_hook=_pairs, parse_constant=invalid)


def read_json(path):
    return strict_json(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    temporary.replace(path)


def facts_from_text(text):
    facts = {}
    for part in text.split(" | "):
        require(": " in part, f"Invalid fact: {part}")
        key, value = part.split(": ", 1)
        require(
            key not in facts and key.strip() and value.strip(), "Duplicate/empty field"
        )
        facts[key] = value
    return facts


def input_issues(facts):
    """Semantic numeric checks, not just hash/schema checks."""
    issues = []
    numeric = {}
    integers = {
        "CashDeposits",
        "DistinctBranches",
        "OutboundTransfers",
        "DistinctBeneficiaryAccounts",
        "TxnCount1h",
        "AccountHistoryMonths",
        "FailedAuth24h",
        "DepositWindowDays",
        "Hour",
    }
    flags = {
        "MicroTxn",
        "OffHours",
        "LargeTxn",
        "RoundAmt",
        "NewDevice",
        "NewCountry",
        "CustomerVerified",
        "NewBeneficiary",
        "BeneficiaryVerified",
        "TravelNotice",
        "Recurring",
    }
    numeric_fields = (
        integers
        | flags
        | {
            "Amount",
            "UsualAmount",
            "SmallestDeposit",
            "LargestDeposit",
            "TotalCashDeposited",
            "InboundAmount",
            "OutboundAmount",
            "ResidualBalance",
            "TransferWindowHours",
            "UtilizationWindowHours",
            "CreditUtilizationBeforePct",
            "CreditUtilizationAfterPct",
        }
    )
    for key, value in facts.items():
        if re.fullmatch(r"\$?-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?", value):
            numeric[key] = float(value.replace("$", "").replace(",", ""))
            if not math.isfinite(numeric[key]) or numeric[key] < 0:
                issues.append(f"invalid_number:{key}")
        elif key in numeric_fields:
            issues.append(f"invalid_number:{key}")
    numeric = {k: v for k, v in numeric.items() if math.isfinite(v)}
    for key in integers:
        if key in numeric and not numeric[key].is_integer():
            issues.append(f"non_integer:{key}")
    for key in flags:
        if key in numeric and numeric[key] not in {0, 1}:
            issues.append(f"invalid_flag:{key}")
    for key in ("CreditUtilizationBeforePct", "CreditUtilizationAfterPct"):
        if key in numeric and numeric[key] > 100:
            issues.append(f"out_of_range:{key}")
    if "Hour" in numeric and (
        numeric["Hour"] >= 24 or numeric["Hour"] != int(numeric["Hour"])
    ):
        issues.append("invalid_hour")
    deposit_keys = {
        "CashDeposits",
        "SmallestDeposit",
        "LargestDeposit",
        "TotalCashDeposited",
    }
    if deposit_keys <= numeric.keys():
        n, low, high, total = [
            numeric[k]
            for k in (
                "CashDeposits",
                "SmallestDeposit",
                "LargestDeposit",
                "TotalCashDeposited",
            )
        ]
        if n < 1 or low > high or (n == 1 and not low == high == total):
            issues.append("deposit_arithmetic")
        elif n >= 2 and not (n - 1) * low + high <= total <= low + (n - 1) * high:
            issues.append("deposit_arithmetic")
    for count, distinct in (
        ("CashDeposits", "DistinctBranches"),
        ("OutboundTransfers", "DistinctBeneficiaryAccounts"),
    ):
        if {count, distinct} <= numeric.keys() and numeric[distinct] > numeric[count]:
            issues.append(f"distinct_exceeds_count:{distinct}")
    if {"InboundAmount", "OutboundAmount", "ResidualBalance"} <= numeric.keys():
        if (
            abs(
                numeric["InboundAmount"]
                - numeric["OutboundAmount"]
                - numeric["ResidualBalance"]
            )
            > 0.005
        ):
            issues.append("transfer_arithmetic")
    return sorted(set(issues))


def validate_testset(payload):
    require(isinstance(payload, dict), "Test set must be an object")
    require(
        payload.get("schema_version") == 4
        and payload.get("bundle_version") == FIXTURE_VERSION,
        "Wrong test-set version",
    )
    require(payload.get("counts") == COUNTS, "Wrong case counts")
    require(payload.get("source_v3_sha256") == LEGACY_SHA256, "Wrong historical source")
    cases = payload.get("cases")
    require(
        isinstance(cases, list) and len(cases) == sum(COUNTS.values()),
        "Incomplete cases",
    )
    seen, prompts, source_ids = set(), set(), set()
    for case in cases:
        require(isinstance(case, dict), "Invalid case")
        require(case.get("task") in COUNTS, "Unknown task")
        identifier = case.get("id")
        require(
            isinstance(identifier, str) and identifier and identifier not in seen,
            "Duplicate/missing case ID",
        )
        seen.add(identifier)
        require(
            isinstance(case.get("input"), str) and case["input"].strip(), "Empty input"
        )
        prompt_key = (case["task"], case["input"])
        require(prompt_key not in prompts, "Duplicate input")
        prompts.add(prompt_key)
        if case["task"] == "risk_assessment":
            facts = facts_from_text(case["input"])
            require(case.get("facts") == facts, "Facts differ from prompt")
            require(
                case.get("expected_tier") in TIERS
                and case.get("expected_pattern") in PATTERNS
                and case.get("expected_action") in ACTIONS,
                "Invalid risk target",
            )
            keys = case.get("required_evidence")
            require(
                isinstance(keys, list)
                and len(keys) == len(set(keys))
                and len(keys) >= min(2, len(facts))
                and set(keys) <= facts.keys(),
                "Invalid evidence fields",
            )
            issues = input_issues(facts)
            if case.get("input_status") == "contradictory":
                require(
                    bool(issues)
                    and case["expected_tier"] == "UNDETERMINED"
                    and case["expected_pattern"] == "undetermined"
                    and case["expected_action"] == "review",
                    "Contradiction must target abstention",
                )
            else:
                require(
                    case.get("input_status") == "valid" and not issues,
                    f"Invalid fixture {identifier}: {issues}",
                )
            require(
                isinstance(case.get("family"), str) and bool(case["family"]),
                "Missing family",
            )
        elif case["task"] == "classification":
            require(
                case.get("expected_label") in {"FRAUD", "LEGITIMATE"},
                "Invalid class target",
            )
            source = case.get("source_record_id")
            require(
                isinstance(source, str) and source and source not in source_ids,
                "Duplicate/missing source record",
            )
            source_ids.add(source)
        else:
            require(
                CITATION.fullmatch(case.get("expected_citation", "")) is not None,
                "Invalid citation target",
            )
            require(
                not CITATION.search(case["input"]),
                "Regulatory input gives away a citation",
            )
            require(
                case.get("content_review_required") is True,
                "Regulatory content needs independent review",
            )
    require(dict(Counter(c["task"] for c in cases)) == COUNTS, "Task count mismatch")
    require(
        {c["expected_tier"] for c in cases if c["task"] == "risk_assessment"} == TIERS,
        "Missing tier/abstention coverage",
    )
    require(
        Counter(c["expected_label"] for c in cases if c["task"] == "classification")
        == {"FRAUD": 100, "LEGITIMATE": 100},
        "Class balance changed",
    )
    return payload


def verify_bundle(bundle, expected_files):
    bundle = Path(bundle)
    require(
        set(expected_files) == {"domain_eval.py", "testset.json"},
        "Incomplete expected hashes",
    )
    manifest = read_json(bundle / "bundle_manifest.json")
    require(
        manifest.get("bundle_version") == BUNDLE_VERSION
        and manifest.get("files") == expected_files,
        "Stale/mismatched manifest",
    )
    for name, expected in expected_files.items():
        require(sha256(bundle / name) == expected, f"Corrupt bundle file: {name}")
    require(
        sha256(__file__) == expected_files["domain_eval.py"],
        "Imported evaluator differs from bundle",
    )
    payload = validate_testset(read_json(bundle / "testset.json"))
    require(
        manifest.get("case_count") == len(payload["cases"]),
        "Manifest case count mismatch",
    )
    return payload


def adapter_identity(adapter):
    adapter = Path(adapter)
    require(
        adapter.name == "Llama-3.1-8B-IOS-Risk-v1"
        and not any(p.startswith("checkpoint-") for p in adapter.parts),
        "Select final training adapter",
    )
    config = read_json(adapter / "adapter_config.json")
    require(
        config.get("peft_type") == "LORA" and config.get("task_type") == "CAUSAL_LM",
        "Unsupported adapter type",
    )
    base = str(config.get("base_model_name_or_path", "")).lower()
    require(
        base in {BASE_MODEL, "unsloth/meta-llama-3.1-8b-instruct"},
        "Wrong adapter base model",
    )
    weights = adapter / "adapter_model.safetensors"
    size = weights.stat().st_size
    require(size >= 10_000_000, "Adapter weights suspiciously small")
    with weights.open("rb") as handle:
        length = struct.unpack("<Q", handle.read(8))[0]
        require(0 < length < min(size - 8, 2_000_000), "Invalid safetensors header")
        header = strict_json(handle.read(length).decode())
    tensors = [value for key, value in header.items() if key != "__metadata__"]
    require(bool(tensors), "Empty adapter")
    end = 0
    for tensor in sorted(tensors, key=lambda x: x["data_offsets"][0]):
        start, stop = tensor["data_offsets"]
        shape = tensor["shape"]
        width = {"F32": 4, "F16": 2, "BF16": 2}.get(tensor["dtype"])
        require(
            width is not None and all(type(d) is int and d > 0 for d in shape),
            "Invalid tensor shape/dtype",
        )
        require(
            start == end and stop - start == math.prod(shape) * width,
            "Truncated/overlapping tensor data",
        )
        end = stop
    require(end + 8 + length == size, "Adapter file truncated or has trailing data")
    return {
        "directory_name": adapter.name,
        "weights_sha256": sha256(weights),
        "config_sha256": sha256(adapter / "adapter_config.json"),
        "bytes": size,
    }


def prompt_for(case):
    instruction = {
        "classification": CLASS_INSTRUCTION,
        "risk_assessment": RISK_INSTRUCTION,
        "regulatory_identification": REG_INSTRUCTION,
    }[case["task"]]
    return instruction + "\n\nSupplied input:\n" + case["input"]


def validate_chat_tokenizer(tokenizer):
    """Reject drift before loading weights; use the pinned native tokenizer."""
    template = tokenizer.chat_template
    require(isinstance(template, str), "Missing native chat template")
    require(
        hashlib.sha256(template.encode()).hexdigest() == CHAT_TEMPLATE_SHA256,
        "Native chat template differs from pinned model revision",
    )
    vocab = tokenizer.get_vocab()
    require(
        all(vocab.get(token) == value for token, value in CONTROL_TOKENS.items()),
        "Unexpected Llama chat control-token IDs",
    )
    require(tokenizer.bos_token_id == 128000, "Unexpected BOS token")
    require(tokenizer.eos_token_id == 128009, "Unexpected end-of-turn token")


def render_chat(tokenizer, prompt):
    require(isinstance(prompt, str) and prompt.strip(), "Empty prompt")
    # Fixture contents must not inject role boundaries into the native template.
    require(not re.search(r"<\|[^\n]*?\|>", prompt), "Control token in prompt data")
    rendered = tokenizer.apply_chat_template(
        [{"role": "user", "content": prompt}],
        tokenize=False,
        add_generation_prompt=True,
        date_string=CHAT_DATE,
    )
    require(
        rendered.startswith("<|begin_of_text|>")
        and rendered.count("<|begin_of_text|>") == 1
        and rendered.endswith("<|start_header_id|>assistant<|end_header_id|>\n\n"),
        "Native chat lacks a single BOS or assistant generation header",
    )
    return rendered


def invalid_continuation(text, task):
    """Early failure only. Never extract/repair an answer or award a success."""
    require(task in COUNTS, "Unknown generation task")
    if re.search(r"<\|[^\n]*?\|>", text):
        return "unexpected_control_token"
    if re.search(r"(?:^|\n)[ \t]*#{3}\s*(?:Response|Instruction|Input)\b", text):
        return "repeated_turn"
    stripped = text.lstrip()
    if task == "classification" and stripped:
        value = stripped.upper()
        if not any(
            label.startswith(value) or value.strip() == label
            for label in ("FRAUD", "LEGITIMATE")
        ):
            return "invalid_label_continuation"
    if task == "risk_assessment" and stripped:
        if not stripped.startswith("{"):
            return "invalid_json_prefix"
        try:
            _, end = json.JSONDecoder().raw_decode(stripped)
        except ValueError:
            pass  # Incomplete prefixes can become valid JSON; do not cut them off.
        else:
            if stripped[end:].strip():
                return "extra_content_after_json"
    return None


def generation_record(tokenizer, ids, prompt_ids, rendered, limit, task, elapsed):
    """Keep raw token evidence; strip only one recognized terminal answer token."""
    ended = bool(ids) and ids[-1] in ANSWER_END_IDS
    content_ids = ids[:-1] if ended else ids
    raw = tokenizer.decode(ids, skip_special_tokens=False)
    text = tokenizer.decode(content_ids, skip_special_tokens=False).strip()
    invalid = invalid_continuation(text, task)
    finish = invalid or (
        "eos" if ended else "length" if len(ids) >= limit else "stopped_without_eos"
    )
    return {
        "text": text,
        "raw_text": raw,
        "prompt_tokens": len(prompt_ids),
        "prompt_sha256": hashlib.sha256(rendered.encode()).hexdigest(),
        "prompt_token_ids_sha256": canonical_hash(prompt_ids),
        "chat_template_sha256": CHAT_TEMPLATE_SHA256,
        "stop_policy": STOP_POLICY,
        "eos_token_ids": sorted(GENERATION_STOP_IDS),
        "generated_tokens": len(ids),
        "generated_token_ids": ids,
        "max_new_tokens": limit,
        "finish_reason": finish,
        "elapsed_seconds": round(elapsed, 3),
    }


def unsupported_claims(response, facts):
    """Conservative diagnostic rules, not an exhaustive semantic truth judge."""
    text = response.lower().replace("–", "-").replace("—", "-")
    flags = []
    # A number must be attached to the probability/score, not elsewhere in prose.
    if re.search(
        r"\b(?:probability|confidence|likelihood|(?:aml |fraud |model |risk )?score)\s*(?:of fraud\s*)?(?:(?:of|is|at)\s*)?[:=]?\s*\d",
        text,
    ) or re.search(
        r"\b\d+(?:\.\d+)?\s*%\s*(?:probability|confidence|likelihood)", text
    ):
        flags.append("invented_score_or_probability")
    sentences = re.split(r"[.!?;]\s*|\bbut\b|\bhowever\b", text)
    for phrase, available in (
        (r"\bdevice\b|\bnew-device\b", {"NewDevice", "DeviceHistory"}),
        (
            r"\bgeolocation\b|\blocation\b",
            {"NewCountry", "Geolocation", "DistinctBranches"},
        ),
        (r"\bmerchant category\b", {"MerchantCategory"}),
    ):
        if available & facts.keys():
            continue
        for sentence in sentences:
            if re.search(phrase, sentence) and not re.search(
                r"(?:not (?:supplied|provided|known|available)|unknown|unavailable|cannot (?:assess|determine|infer))",
                sentence,
            ):
                flags.append("unsupported_field:" + phrase)
    if "TxnCount1h" in facts:
        if re.search(
            r"(?:once|single|one|1)\b.{0,65}(?:24[- ]hour|past 24 hours)", text
        ):
            flags.append("unsupported_24h_transaction_count")
    if "TransactionHistory" not in facts:
        if re.search(
            r"\bno prior (?:similar )?activity\b|\bno prior similar transactions\b",
            text,
        ):
            flags.append("unsupported_transaction_history")
        if re.search(
            r"(?:single|one) (?:event|transaction).{0,50}\b\d+[- ]month", text
        ):
            flags.append("account_age_used_as_transaction_history")
    if "Amount" in facts and re.search(
        r"transactions (?:totaling|totalling)|total (?:of|amount)\s*\$", text
    ):
        flags.append("current_amount_used_as_aggregate")
    return sorted(set(flags))


def parse_risk(response):
    try:
        value = strict_json(response.strip())
        if not isinstance(value, dict) or set(value) != {
            "tier",
            "pattern",
            "action",
            "evidence",
            "rationale",
        }:
            return None
        if not all(
            isinstance(value[k], str)
            for k in ("tier", "pattern", "action", "rationale")
        ):
            return None
        value["tier"] = value["tier"].upper()
        for key in ("pattern", "action"):
            value[key] = value[key].lower().replace("-", "_").replace(" ", "_")
        if (
            value["tier"] not in TIERS
            or value["pattern"] not in PATTERNS
            or value["action"] not in ACTIONS
        ):
            return None
        if not value["rationale"].strip() or not isinstance(value["evidence"], dict):
            return None
        if not all(
            isinstance(k, str) and isinstance(v, str)
            for k, v in value["evidence"].items()
        ):
            return None
        return value
    except (ValueError, TypeError):
        return None


def score_case(case, generation):
    response = generation["text"]
    complete = generation["finish_reason"] == "eos" and bool(response.strip())
    result = {
        "id": case["id"],
        "task": case["task"],
        "generation": generation,
        "input": case["input"],
        "valid_output": False,
        "manual_review_required": True,
    }
    if case["task"] == "classification":
        label = response.strip().upper()
        valid = complete and label in {"FRAUD", "LEGITIMATE"}
        result.update(
            valid_output=valid,
            predicted_label=label if valid else None,
            expected_label=case["expected_label"],
            manual_review_required=False,
        )
    elif case["task"] == "regulatory_identification":
        citations = sorted(set(CITATION.findall(response)))
        target = CITATION.fullmatch(case["expected_citation"]).group(1)
        result.update(
            valid_output=complete,
            citation_identified=complete and citations == [target],
            expected_citation=case["expected_citation"],
            cited_sections=citations,
            legal_content_accuracy=None,
        )
    else:
        answer = parse_risk(response)
        valid = (
            complete
            and answer is not None
            and len(answer["evidence"]) >= min(2, len(case["facts"]))
        )
        flags = unsupported_claims(
            answer["rationale"] if answer else response, case["facts"]
        )
        evidence_ok = False
        if answer:
            rationale = answer["rationale"].lower()
            if answer["action"] == "restrict" and re.search(
                r"\b(?:do not|don't|must not|should not) (?:block|hold|freeze|restrict)\b",
                rationale,
            ):
                flags.append("rationale_conflicts_with_action")
            pattern_phrase = re.escape(answer["pattern"]).replace("_", "[- ]")
            if answer["pattern"] not in {"legitimate", "undetermined"} and re.search(
                r"\b(?:no|not|no evidence of) " + pattern_phrase + r"\b", rationale
            ):
                flags.append("rationale_denies_declared_pattern")
            for key, value in answer["evidence"].items():
                if case["facts"].get(key) != value:
                    flags.append(f"unsupported_evidence:{key}")
            # Match the public prompt, not a hidden list of preferred keywords/fields.
            evidence_ok = len(answer["evidence"]) >= min(2, len(case["facts"])) and all(
                case["facts"].get(k) == v for k, v in answer["evidence"].items()
            )
        checks = {
            f"correct_{key}": valid and answer[key] == case[f"expected_{key}"]
            for key in ("tier", "pattern", "action")
        }
        result.update(
            valid_output=valid,
            answer=answer,
            family=case["family"],
            expected_tier=case["expected_tier"],
            expected_pattern=case["expected_pattern"],
            expected_action=case["expected_action"],
            evidence_fields_correct=valid and evidence_ok,
            unsupported_claims=sorted(set(flags)),
            **checks,
        )
        # Separate dimensions; no keyword-average 'quality' or inferred legal approval.
    return result


def classification_metrics(rows):
    counts = Counter()
    for row in rows:
        expected, predicted = row["expected_label"], row["predicted_label"]
        if predicted is None:
            counts[
                "invalid_fraud" if expected == "FRAUD" else "invalid_legitimate"
            ] += 1
        else:
            counts[
                {
                    ("FRAUD", "FRAUD"): "tp",
                    ("FRAUD", "LEGITIMATE"): "fn",
                    ("LEGITIMATE", "FRAUD"): "fp",
                    ("LEGITIMATE", "LEGITIMATE"): "tn",
                }[(expected, predicted)]
            ] += 1
    output = {
        key: counts[key]
        for key in ("tp", "fp", "fn", "tn", "invalid_fraud", "invalid_legitimate")
    }
    invalid = counts["invalid_fraud"] + counts["invalid_legitimate"]
    n = len(rows)
    output.update(
        n=n,
        valid_count=n - invalid,
        invalid_count=invalid,
        protocol_valid=n > 0 and invalid == 0,
        accuracy_including_invalid=(counts["tp"] + counts["tn"]) / n if n else None,
    )
    # Do not publish a capability precision/recall/F1 when outputs are unusable.
    tp, fp, fn = counts["tp"], counts["fp"], counts["fn"]
    output.update(
        precision=tp / (tp + fp) if not invalid and tp + fp else None,
        recall=tp / (tp + fn) if not invalid and tp + fn else None,
        f1=2 * tp / (2 * tp + fp + fn) if not invalid and 2 * tp + fp + fn else None,
    )
    return output


def summarize(rows, mode):
    risk = [r for r in rows if r["task"] == "risk_assessment"]
    regs = [r for r in rows if r["task"] == "regulatory_identification"]

    def rate(values):
        return sum(values) / len(values) if values else None

    return {
        "mode": mode,
        "n": len(rows),
        "invalid_outputs": sum(not r["valid_output"] for r in rows),
        "classification": classification_metrics(
            [r for r in rows if r["task"] == "classification"]
        ),
        "risk_assessment": {
            "n": len(risk),
            "families": len({r["family"] for r in risk}),
            **{
                key: rate([r[key] for r in risk])
                for key in (
                    "correct_tier",
                    "correct_pattern",
                    "correct_action",
                    "evidence_fields_correct",
                )
            },
            "by_family": {
                family: {
                    "n": sum(r["family"] == family for r in risk),
                    **{
                        key: rate([r[key] for r in risk if r["family"] == family])
                        for key in (
                            "correct_tier",
                            "correct_pattern",
                            "correct_action",
                            "evidence_fields_correct",
                        )
                    },
                }
                for family in sorted({r["family"] for r in risk})
            },
            "flagged_claim_rate_diagnostic": rate(
                [bool(r["unsupported_claims"]) for r in risk]
            ),
            "factual_accuracy": None,
        },
        "regulatory_identification": {
            "n": len(regs),
            "citation_identification_rate": rate(
                [r["citation_identified"] for r in regs]
            ),
            "legal_content_accuracy": None,
        },
        "release_status": "NOT_ASSESSED_SMOKE"
        if mode == "smoke"
        else "REVIEW_REQUIRED",
        "limitations": [
            "New protocol; not directly comparable to v3",
            "Development-exposed benchmark; independent confirmation needed",
            "Grounding flags are not exhaustive",
            "Evidence correctness checks copied fields, not reasoning relevance",
            "Authored risk targets and legal content require independent review",
        ],
    }


def smoke_cases(cases):
    picked = []
    for tier in sorted(TIERS):
        picked.append(
            next(
                c
                for c in cases
                if c["task"] == "risk_assessment" and c["expected_tier"] == tier
            )
        )
    picked.append(next(c for c in cases if c.get("input_status") == "contradictory"))
    for label in ("FRAUD", "LEGITIMATE"):
        picked.append(next(c for c in cases if c.get("expected_label") == label))
    picked.append(next(c for c in cases if c["task"] == "regulatory_identification"))
    return list({c["id"]: c for c in picked}.values())


class GPUBackend:
    """Only this explicitly called backend imports CUDA libraries or loads weights."""

    @contextmanager
    def session(self, tag, adapter):
        from unsloth import FastLanguageModel
        import torch
        from peft import PeftModel
        from transformers import AutoTokenizer

        model = tokenizer = None
        try:
            require(torch.cuda.is_available(), "CUDA GPU required")
            require(torch.cuda.get_device_capability(0)[0] >= 7, "T4 or newer required")
            require(tag in {"base", "tuned"}, "Unknown model tag")
            # Use the same canonical tokenizer for both models, not a training
            # tokenizer whose template may have been rewritten by a wrapper.
            tokenizer = AutoTokenizer.from_pretrained(
                BASE_MODEL, revision=BASE_REVISION, trust_remote_code=False
            )
            validate_chat_tokenizer(tokenizer)
            model, _training_tokenizer = FastLanguageModel.from_pretrained(
                model_name=BASE_MODEL,
                revision=BASE_REVISION,
                max_seq_length=MAX_CONTEXT,
                load_in_4bit=True,
            )
            del _training_tokenizer
            # Explicit generation kwargs below use the validated native IDs.
            # Wrapper-modified defaults are not a reason to reject the model.
            if tag == "tuned":
                model = PeftModel.from_pretrained(
                    model, str(adapter), is_trainable=False
                )
            FastLanguageModel.for_inference(model)
            self.model, self.tokenizer = model, tokenizer
            yield self
        finally:
            self.model = self.tokenizer = None
            del model, tokenizer
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

    def generate(self, prompt, limit, task):
        import torch
        from transformers import StoppingCriteria, StoppingCriteriaList

        tokenizer, model = self.tokenizer, self.model
        require(
            task in COUNTS and limit == LIMITS[task], "Unexpected generation budget"
        )
        rendered = render_chat(tokenizer, prompt)
        inputs = tokenizer(
            [rendered], return_tensors="pt", truncation=False, add_special_tokens=False
        )
        require(
            inputs["input_ids"].shape[0] == 1, "Only single-case generation supported"
        )
        count = inputs["input_ids"].shape[1]
        prompt_ids = inputs["input_ids"][0].tolist()
        require(
            count + limit <= MAX_CONTEXT,
            "Prompt/output budget exceeds context; no silent truncation",
        )

        class InvalidOutputStop(StoppingCriteria):
            def __call__(self, input_ids, scores, **kwargs):
                ids = input_ids[0][count:].tolist()
                if ids and ids[-1] in ANSWER_END_IDS:
                    ids = ids[:-1]
                # Never scan the prompt's legitimate role/header tokens.
                text = tokenizer.decode(ids, skip_special_tokens=False)
                failed = invalid_continuation(text, task) is not None
                return torch.tensor([failed], device=input_ids.device, dtype=torch.bool)

        inputs = inputs.to(model.get_input_embeddings().weight.device)
        start = time.monotonic()
        with torch.inference_mode():
            outputs = model.generate(
                **inputs,
                max_new_tokens=limit,
                do_sample=False,
                use_cache=True,
                eos_token_id=sorted(GENERATION_STOP_IDS),
                pad_token_id=tokenizer.eos_token_id,
                stopping_criteria=StoppingCriteriaList([InvalidOutputStop()]),
                max_time=120.0,
            )
        ids = outputs[0][count:].tolist()
        return generation_record(
            tokenizer, ids, prompt_ids, rendered, limit, task, time.monotonic() - start
        )


def verify_smoke_receipt(directory, fingerprint, selected_ids):
    directory = Path(directory)
    receipt = read_json(directory / "smoke_receipt.json")
    require(
        receipt.get("fingerprint") == fingerprint
        and receipt.get("status") == "SMOKE_PASSED",
        "Smoke does not match this protocol/model/environment",
    )
    require(
        set(receipt.get("files", {}))
        == {"base.responses.jsonl", "tuned.responses.jsonl", "comparison.json"},
        "Incomplete smoke receipt",
    )
    for name, digest in receipt["files"].items():
        require(sha256(directory / name) == digest, "Smoke output changed")
    comparison = read_json(directory / "comparison.json")
    require(
        comparison.get("status") == "SMOKE_PASSED"
        and comparison.get("fingerprint") == fingerprint,
        "Invalid smoke comparison",
    )
    base_prompts = {}
    for tag in ("base", "tuned"):
        rows = [
            strict_json(line)
            for line in (directory / f"{tag}.responses.jsonl").read_text().splitlines()
        ]
        require(
            [r.get("id") for r in rows] == selected_ids, "Smoke case coverage differs"
        )
        require(
            all(
                r.get("valid_output") is True
                and r.get("generation", {}).get("finish_reason") == "eos"
                for r in rows
            ),
            "Smoke contains invalid or incomplete outputs",
        )
        require(
            comparison.get("summaries", {}).get(tag) == summarize(rows, "smoke"),
            "Smoke summary does not match raw outputs",
        )
        for row in rows:
            identity = prompt_identity(row["generation"])
            if tag == "base":
                base_prompts[row["id"]] = identity
            else:
                require(
                    identity == base_prompts[row["id"]],
                    "Base/tuned prompt tokens differ",
                )
    return receipt


def prompt_identity(generation):
    require(
        generation.get("chat_template_sha256") == CHAT_TEMPLATE_SHA256
        and generation.get("stop_policy") == STOP_POLICY,
        "Missing or mismatched chat provenance",
    )
    identity = tuple(
        generation.get(key) for key in ("prompt_sha256", "prompt_token_ids_sha256")
    )
    require(
        all(
            isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value)
            for value in identity
        ),
        "Missing prompt digests",
    )
    return identity


def run_pair(
    bundle,
    adapter,
    output,
    expected_files,
    mode="smoke",
    smoke_directory=None,
    allow_full=False,
    backend=None,
    environment=None,
):
    require(mode in {"smoke", "full"}, "Unknown execution mode")
    payload = verify_bundle(bundle, expected_files)
    identity = adapter_identity(adapter)
    if environment is None:
        environment = {name: importlib.metadata.version(name) for name in PINS}
        require(
            all(environment[name] == version for name, version in PINS.items()),
            "Dependency pins do not match",
        )
        environment["torch"] = importlib.metadata.version("torch")
    fingerprint_data = {
        "bundle_version": BUNDLE_VERSION,
        "protocol": PROTOCOL,
        "fixture_version": FIXTURE_VERSION,
        "chat_template_sha256": CHAT_TEMPLATE_SHA256,
        "chat_date": CHAT_DATE,
        "stop_policy": STOP_POLICY,
        "generation_stop_ids": sorted(GENERATION_STOP_IDS),
        "answer_end_ids": sorted(ANSWER_END_IDS),
        "files": expected_files,
        "adapter": identity,
        "base_model": BASE_MODEL,
        "base_revision": BASE_REVISION,
        "limits": LIMITS,
        "context": MAX_CONTEXT,
        "environment": environment,
    }
    fingerprint = canonical_hash(fingerprint_data)
    if mode == "full":
        require(
            allow_full and smoke_directory,
            "Full run requires explicit approval and a successful matching smoke",
        )
        verify_smoke_receipt(
            smoke_directory,
            fingerprint,
            [c["id"] for c in smoke_cases(payload["cases"])],
        )
    output = Path(output)
    require(not output.exists(), "Output already exists; use a fresh run directory")
    output.mkdir(parents=True)
    write_json(
        output / "run_manifest.json",
        {**fingerprint_data, "fingerprint": fingerprint, "mode": mode},
    )
    selected = smoke_cases(payload["cases"]) if mode == "smoke" else payload["cases"]
    backend = backend or GPUBackend()
    summaries = {}
    base_prompts = {}
    started = time.monotonic()
    try:
        for tag in ("base", "tuned"):
            rows = []
            with (output / f"{tag}.responses.jsonl").open(
                "x", encoding="utf-8"
            ) as stream:
                with backend.session(tag, adapter):
                    for case in selected:
                        if time.monotonic() - started > (
                            900 if mode == "smoke" else 7200
                        ):
                            raise ProtocolError(
                                "Wall-clock budget exceeded; partial outputs preserved"
                            )
                        generation = backend.generate(
                            prompt_for(case), LIMITS[case["task"]], case["task"]
                        )
                        result = score_case(case, generation)
                        stream.write(json.dumps(result, allow_nan=False) + "\n")
                        stream.flush()
                        os.fsync(stream.fileno())
                        rows.append(result)
                        identity = prompt_identity(generation)
                        if tag == "base":
                            base_prompts[case["id"]] = identity
                        else:
                            require(
                                identity == base_prompts[case["id"]],
                                "Base/tuned prompt tokens differ",
                            )
                        print(
                            f"{tag} {len(rows)}/{len(selected)} {case['id']} {generation['finish_reason']}",
                            flush=True,
                        )
                        if not result["valid_output"]:
                            raise ProtocolError(
                                f"{tag}/{case['id']}: incomplete or invalid output "
                                f"({generation['finish_reason']}); stop before spending on remaining cases"
                            )
            summaries[tag] = summarize(rows, mode)
            write_json(output / f"{tag}.summary.json", summaries[tag])
            write_json(
                output / f"{tag}.review_queue.json",
                {
                    "status": "UNREVIEWED",
                    "instructions": "Independently review the rationale, fixture target, evidence relevance, and legal content. Automated flags are diagnostic only.",
                    "cases": [r for r in rows if r["manual_review_required"]],
                },
            )
        status = "SMOKE_PASSED" if mode == "smoke" else "COMPLETED_REVIEW_REQUIRED"
        comparison = {
            "status": status,
            "fingerprint": fingerprint,
            "summaries": summaries,
        }
        write_json(output / "comparison.json", comparison)
        if mode == "smoke":
            write_json(
                output / "smoke_receipt.json",
                {
                    "status": status,
                    "fingerprint": fingerprint,
                    "files": {
                        name: sha256(output / name)
                        for name in (
                            "base.responses.jsonl",
                            "tuned.responses.jsonl",
                            "comparison.json",
                        )
                    },
                },
            )
        print(status + ": this is not a release approval", flush=True)
        return comparison
    except BaseException as exc:
        write_json(
            output / "failure.json",
            {
                "status": "INCOMPLETE",
                "error_type": type(exc).__name__,
                "message": str(exc),
                "fingerprint": fingerprint,
                "mode": mode,
            },
        )
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle", required=True)
    parser.add_argument("--adapter", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument(
        "--expected-files",
        required=True,
        help="JSON of trusted hashes from the notebook",
    )
    parser.add_argument("--mode", choices=["smoke", "full"], default="smoke")
    parser.add_argument("--smoke-directory")
    parser.add_argument("--allow-full", action="store_true")
    args = parser.parse_args()
    run_pair(
        args.bundle,
        args.adapter,
        args.out,
        strict_json(args.expected_files),
        args.mode,
        args.smoke_directory,
        args.allow_full,
    )
