"""Run one bounded learning pilot; preserve failure as evidence and never retry."""

from __future__ import annotations

import argparse
import gc
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import os
import re
import time
from collections import Counter
from pathlib import Path

VERSION = "2026-09-01.alignment-pilot.1"
FILES = {
    "runner.py",
    "contract.py",
    "domain_eval.py",
    "pilot_data.json",
    "token_checks.json",
    "review_decisions.json",
}
OPTIONAL_FILES = {"pilot_contract.py"}
WORKER_SECONDS = 3000


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    require(spec is not None and spec.loader is not None, f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_bundle(bundle, expected, authorize_run=False):
    bundle = Path(bundle)
    require(
        FILES <= set(expected) <= FILES | OPTIONAL_FILES,
        "Incomplete or unexpected trusted bundle identities",
    )
    require(digest(__file__) == expected["runner.py"], "Wrong executing runner")
    for name, expected_sha in expected.items():
        require(re.fullmatch(r"[a-f0-9]{64}", expected_sha), "Invalid SHA-256")
        require(digest(bundle / name) == expected_sha, f"Stale or corrupt {name}")
    contract = load_module("checked_pilot_contract", bundle / "contract.py")
    evaluator = load_module("checked_pilot_evaluator", bundle / "domain_eval.py")
    require(
        contract.VERSION in {VERSION, "2026-09-01.evidence-grounding-v2.1"},
        "Contract/runner version mismatch",
    )
    require(
        expected["domain_eval.py"]
        == "1d25210f431e32640d3b8cc7b075b50a7578231dd90f4ff8b8b85e9a6f214b4c",
        "Evaluator identity changed",
    )
    data = evaluator.read_json(bundle / "pilot_data.json")
    checks = evaluator.read_json(bundle / "token_checks.json")
    review = evaluator.read_json(bundle / "review_decisions.json")
    contract.validate_data(data, evaluator)
    contract.validate_review(review, data, authorize_run=authorize_run)
    require(checks.get("schema_version") == contract.VERSION, "Wrong token checks")
    return contract, evaluator, data, checks, review


def package_versions(contract):
    actual = {name: importlib.metadata.version(name) for name in contract.PINS}
    require(actual == contract.PINS, f"Pinned dependency mismatch: {actual}")
    return actual


def trainable_digest(model):
    value = hashlib.sha256()
    count = 0
    for name, parameter in sorted(model.named_parameters()):
        if parameter.requires_grad:
            count += parameter.numel()
            value.update(name.encode())
            value.update(str(tuple(parameter.shape)).encode())
            value.update(parameter.detach().float().cpu().numpy().tobytes())
    return value.hexdigest(), count


def tensor_batch_to_lists(batch):
    return {name: tensor.detach().cpu().tolist() for name, tensor in batch.items()}


def exact_risk(row):
    return bool(
        row.get("valid_output")
        and row.get("correct_tier")
        and row.get("correct_pattern")
        and row.get("correct_action")
        and row.get("evidence_fields_correct")
        and not row.get("unsupported_claims")
    )


def metrics(rows):
    risk = [row for row in rows if row["task"] == "risk_assessment"]
    classes = [row for row in rows if row["task"] == "classification"]
    regulations = [row for row in rows if row["task"] == "regulatory_identification"]
    risk_by_split = {}
    for split in ("development", "frozen_confirmation"):
        selected = [row for row in risk if row.get("pilot_split") == split]
        risk_by_split[split] = {
            "n": len(selected),
            "valid": sum(bool(row["valid_output"]) for row in selected),
            "exact": sum(exact_risk(row) for row in selected),
            "unsupported_claim_flags": sum(
                bool(row["unsupported_claims"]) for row in selected
            ),
        }
    return {
        "n": len(rows),
        "risk": risk_by_split,
        "classification": {
            "n": len(classes),
            "valid": sum(bool(row["valid_output"]) for row in classes),
            "correct": sum(
                row.get("predicted_label") == row.get("expected_label")
                for row in classes
            ),
        },
        "regulatory": {
            "n": len(regulations),
            "valid": sum(bool(row["valid_output"]) for row in regulations),
            "citation_correct": sum(
                bool(row.get("citation_identified")) for row in regulations
            ),
            "legal_content_accuracy": None,
        },
    }


def write_jsonl(path, rows):
    with Path(path).open("x", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, allow_nan=False) + "\n")
            handle.flush()
            os.fsync(handle.fileno())


def evaluate_models(contract, evaluator, cases, adapter, output, started):
    all_rows, all_metrics = {}, {}
    prompt_identities = {}
    backend = evaluator.GPUBackend()
    for tag in ("base", "tuned"):
        rows = []
        with backend.session(tag, adapter):
            for index, case in enumerate(cases, 1):
                require(
                    time.monotonic() - started < WORKER_SECONDS,
                    "Pilot wall-clock deadline exceeded",
                )
                generation = backend.generate(
                    evaluator.prompt_for(case),
                    evaluator.LIMITS[case["task"]],
                    case["task"],
                )
                if hasattr(contract, "score_case"):
                    result = contract.score_case(evaluator, case, generation)
                else:
                    result = evaluator.score_case(case, generation)
                if "pilot_split" in case:
                    result["pilot_split"] = case["pilot_split"]
                identity = evaluator.prompt_identity(generation)
                if tag == "base":
                    prompt_identities[case["id"]] = identity
                else:
                    require(
                        identity == prompt_identities[case["id"]],
                        "Base/tuned prompts differ",
                    )
                rows.append(result)
                print(
                    f"{tag} {index}/{len(cases)} {case['id']} {generation['finish_reason']}",
                    flush=True,
                )
        write_jsonl(output / f"{tag}.responses.jsonl", rows)
        all_rows[tag] = rows
        all_metrics[tag] = metrics(rows)
        evaluator.write_json(output / f"{tag}.metrics.json", all_metrics[tag])
    return all_rows, all_metrics


def outcome(metrics_by_model, contract=None):
    base, tuned = metrics_by_model["base"], metrics_by_model["tuned"]
    base_confirmation = base["risk"]["frozen_confirmation"]
    tuned_confirmation = tuned["risk"]["frozen_confirmation"]
    retention_not_worse = (
        tuned["classification"]["correct"] >= base["classification"]["correct"]
        and tuned["classification"]["valid"] >= base["classification"]["valid"]
        and tuned["regulatory"]["citation_correct"]
        >= base["regulatory"]["citation_correct"]
        and tuned["regulatory"]["valid"] >= base["regulatory"]["valid"]
    )
    minimum_valid = getattr(contract, "EXPECTED_MIN_CONFIRMATION_VALID", 12)
    signal = (
        tuned_confirmation["exact"] > base_confirmation["exact"]
        and tuned_confirmation["valid"] >= minimum_valid
        and tuned_confirmation["unsupported_claim_flags"] == 0
        and retention_not_worse
    )
    signal_status = getattr(
        contract,
        "SIGNAL_STATUS",
        "PILOT_LEARNING_SIGNAL_OBSERVED_REVIEW_REQUIRED",
    )
    no_signal_status = getattr(
        contract,
        "NO_SIGNAL_STATUS",
        "PILOT_COMPLETE_NO_LEARNING_CLAIM",
    )
    return (signal_status if signal else no_signal_status), retention_not_worse


def run(bundle, expected, output):
    started = time.monotonic()
    contract, evaluator, data, checks, review = load_bundle(
        bundle, expected, authorize_run=True
    )
    versions = package_versions(contract)

    from unsloth import FastLanguageModel
    import torch
    from datasets import Dataset, disable_caching, disable_progress_bars
    from transformers import AutoTokenizer, TrainerCallback
    from transformers.utils.hub import cached_file
    from trl import SFTConfig, SFTTrainer

    require(torch.__version__.split("+")[0] == "2.10.0", "Wrong torch version")
    require(
        torch.cuda.is_available() and torch.cuda.device_count() == 2, "Select T4 x2"
    )
    require(
        all(
            torch.cuda.get_device_capability(i) == (7, 5)
            and "T4" in torch.cuda.get_device_name(i)
            for i in range(2)
        ),
        "This exact pilot is approved only for two Tesla T4 GPUs",
    )
    torch.manual_seed(42)
    torch.cuda.manual_seed_all(42)
    disable_caching()
    disable_progress_bars()

    tokenizer = AutoTokenizer.from_pretrained(
        contract.BASE_MODEL, revision=contract.BASE_REVISION, trust_remote_code=False
    )
    evaluator.validate_chat_tokenizer(tokenizer)
    for name, expected_sha in contract.TOKENIZER_HASHES.items():
        require(
            digest(
                cached_file(
                    contract.BASE_MODEL,
                    name,
                    revision=contract.BASE_REVISION,
                    _raise_exceptions_for_gated_repo=True,
                    _raise_exceptions_for_missing_entries=True,
                    _raise_exceptions_for_connection_errors=True,
                )
            )
            == expected_sha,
            f"Tokenizer file changed: {name}",
        )
    tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"
    features, references, details = contract.feature_rows(data, tokenizer, evaluator)
    contract.verify_token_checks(data, checks, tokenizer, evaluator)

    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    adapter = output / contract.OUTPUT_NAME
    model, training_tokenizer = FastLanguageModel.from_pretrained(
        model_name=contract.BASE_MODEL,
        revision=contract.BASE_REVISION,
        max_seq_length=contract.MAX_LENGTH,
        load_in_4bit=True,
    )
    del training_tokenizer
    model = FastLanguageModel.get_peft_model(
        model,
        r=16,
        target_modules=[
            "q_proj",
            "k_proj",
            "v_proj",
            "o_proj",
            "gate_proj",
            "up_proj",
            "down_proj",
        ],
        lora_alpha=16,
        lora_dropout=0,
        bias="none",
        use_gradient_checkpointing="unsloth",
        random_state=42,
    )
    trainable, _all = model.get_nb_trainable_parameters()
    require(
        trainable == contract.EXPECTED_TRAINABLE_PARAMETERS,
        "Unexpected trainable count",
    )
    require(
        all(
            "lora_" in name
            for name, parameter in model.named_parameters()
            if parameter.requires_grad
        ),
        "A non-LoRA parameter is trainable",
    )

    class GradientAudit(TrainerCallback):
        def __init__(self):
            self.calls = 0
            self.max_abs = 0.0

        def on_pre_optimizer_step(self, args, state, control, model=None, **kwargs):
            del args, state, control, kwargs
            gradients = [
                p.grad
                for p in model.parameters()
                if p.requires_grad and p.grad is not None
            ]
            require(
                gradients and all(torch.isfinite(g).all().item() for g in gradients),
                "Missing/non-finite gradients",
            )
            self.calls += 1
            self.max_abs = max(
                self.max_abs, max(float(g.detach().abs().max()) for g in gradients)
            )

    audit = GradientAudit()
    trainer = SFTTrainer(
        model=model,
        args=SFTConfig(
            output_dir=str(output / "trainer-state"),
            max_steps=contract.EXPECTED_OPTIMIZER_STEPS,
            per_device_train_batch_size=contract.EXPECTED_BATCH_SIZE,
            gradient_accumulation_steps=contract.EXPECTED_GRADIENT_ACCUMULATION,
            learning_rate=1e-4,
            lr_scheduler_type="constant",
            warmup_steps=0,
            weight_decay=0.0,
            optim="adamw_8bit",
            logging_steps=1,
            save_strategy="no",
            report_to="none",
            seed=42,
            data_seed=42,
            packing=False,
            padding_free=False,
            max_length=contract.MAX_LENGTH,
            completion_only_loss=True,
            assistant_only_loss=False,
            dataset_num_proc=None,
            dataloader_num_workers=0,
            dataloader_pin_memory=False,
            fp16=True,
            bf16=False,
        ),
        processing_class=tokenizer,
        train_dataset=Dataset.from_list(features),
        callbacks=[audit],
    )
    require(
        len(trainer.train_dataset) == contract.EXPECTED_TRAINING_ROWS,
        "Trainer dropped training rows",
    )
    verified = []
    for batch in trainer.get_train_dataloader():
        verified.extend(
            contract.verify_batch(
                tensor_batch_to_lists(batch),
                references,
                trainer.data_collator.pad_token_id,
            )
        )
    require(
        Counter(verified)
        == Counter(reference["id"] for reference in references.values()),
        "Dataloader omitted or duplicated rows",
    )

    before_sha, before_count = trainable_digest(model)
    train_result = trainer.train()
    loss = float(train_result.training_loss)
    require(
        trainer.state.global_step == contract.EXPECTED_OPTIMIZER_STEPS
        and audit.calls == contract.EXPECTED_OPTIMIZER_STEPS
        and math.isfinite(loss)
        and loss > 0
        and math.isfinite(audit.max_abs)
        and audit.max_abs > 0,
        "Training-step/loss/gradient contract failed",
    )
    after_sha, after_count = trainable_digest(model)
    require(
        before_count == after_count == trainable and before_sha != after_sha,
        "Adapter weights did not change",
    )
    adapter.mkdir()
    model.save_pretrained(adapter)
    tokenizer.save_pretrained(adapter)
    weights = adapter / "adapter_model.safetensors"
    require(
        weights.stat().st_size > 10_000_000
        and (adapter / "adapter_config.json").is_file(),
        "Truncated adapter",
    )
    weights_sha = digest(weights)
    del trainer, model
    gc.collect()
    torch.cuda.empty_cache()

    cases = contract.evaluation_cases(data, evaluator)
    require(
        len(cases) == contract.EXPECTED_EVALUATION_CASES,
        "Wrong evaluation case count",
    )
    _rows, metric_values = evaluate_models(
        contract, evaluator, cases, adapter, output, started
    )
    status, retention_not_worse = outcome(metric_values, contract)
    summary = {
        "status": status,
        "schema_version": contract.VERSION,
        "data_version": contract.DATA_VERSION,
        "data_sha256": expected["pilot_data.json"],
        "review_sha256": expected["review_decisions.json"],
        "base_model": contract.BASE_MODEL,
        "base_revision": contract.BASE_REVISION,
        "output_name": contract.OUTPUT_NAME,
        "training_rows": len(details),
        "optimizer_steps": contract.EXPECTED_OPTIMIZER_STEPS,
        "training_loss": loss,
        "gradient_audit": {
            "pre_optimizer_calls": audit.calls,
            "maximum_absolute_gradient": audit.max_abs,
        },
        "trainable_parameters": trainable,
        "trainable_sha256_before": before_sha,
        "trainable_sha256_after": after_sha,
        "adapter_weights_bytes": weights.stat().st_size,
        "adapter_weights_sha256": weights_sha,
        "metrics": metric_values,
        "retention_not_worse_than_base_on_nine_development_exposed_cases": retention_not_worse,
        "runtime_seconds": time.monotonic() - started,
        "versions": {**versions, "torch": torch.__version__},
        "gpu": {
            "visible": 2,
            "names": [torch.cuda.get_device_name(i) for i in range(2)],
        },
        "independent_confirmation": False,
        "qualified_domain_review": False,
        "production_authorized": False,
        "release_authorized": False,
        "distillation_authorized": False,
        "automatic_retry_authorized": False,
        "limitations": data["limitations"],
    }
    evaluator.write_json(output / "pilot_summary.json", summary)
    print(json.dumps(summary, indent=2, allow_nan=False))
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--expected-files", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--run", action="store_true")
    args = parser.parse_args()
    expected = json.loads(args.expected_files)
    if args.run:
        run(args.bundle, expected, args.out)
    else:
        load_bundle(args.bundle, expected, authorize_run=False)
        print(
            "CPU pilot bundle preflight passed; launch authorization remains separately enforced."
        )


if __name__ == "__main__":
    main()
