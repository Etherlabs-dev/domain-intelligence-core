"""Pure validation and token-mask construction for the bounded integration run."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

VERSION = "2026-09-01.alignment-integration.1"
DATA_VERSION = "structured-risk-dev-0.2-owner-reviewed-2026-09-01"
CANDIDATE_SHA256 = "07fbbf7540c98232f042aca134c73106aff5b87c1a0191bd795187160aa38556"
REVIEW_SHA256 = "b8b25d7183f5b43a5e218ae1971f93bc6f94f5f2bb1d51ea0233656c724e5e33"
EVALUATOR_SHA256 = "1d25210f431e32640d3b8cc7b075b50a7578231dd90f4ff8b8b85e9a6f214b4c"
BASE_MODEL = "unsloth/meta-llama-3.1-8b-instruct-unsloth-bnb-4bit"
BASE_REVISION = "0db785ab56c082e30ae7dea3645d45465fbb5797"
OUTPUT_NAME = "Llama-3.1-8B-IOS-Risk-JSON-v0.1-integration"
CHAT_DATE = "31 Aug 2026"
RECORD_IDS = [f"dev-json-{index:03d}" for index in range(1, 16)]
MAX_LENGTH = 1024
EXPECTED_BATCH_SIZE = 2
EXPECTED_GRADIENT_ACCUMULATION = 8
EXPECTED_MICROBATCHES = 8
EXPECTED_OPTIMIZER_STEPS = 1
EXPECTED_TRAINABLE_PARAMETERS = 41_943_040
TOKENIZER_HASHES = {
    "tokenizer.json": (
        "6b9e4e7fb171f92fd137b777cc2714bf87d11576700a1dcd7a399e7bbe39537b"
    ),
    "tokenizer_config.json": (
        "4d18eae3017839b17cb3598f589b62ec212652d183582ee0fc33a4f1e8b3da67"
    ),
}
PINS = {
    "transformers": "5.5.0",
    "datasets": "4.3.0",
    "trl": "0.24.0",
    "bitsandbytes": "0.50.1",
    "xformers": "0.0.34",
    "peft": "0.19.1",
    "unsloth": "2026.8.22",
    "unsloth_zoo": "2026.8.16",
}
FILES = {
    "runner.py",
    "contract.py",
    "domain_eval.py",
    "alignment_data.json",
    "token_checks.json",
}


class ContractError(ValueError):
    """Fail-closed input or runtime-contract error."""


def require(condition, message):
    if not condition:
        raise ContractError(message)


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def canonical_hash(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, allow_nan=False).encode()
    ).hexdigest()


def validate_review(candidate, review):
    require(review.get("schema_version") == "label-review-record.1", "Wrong review")
    require(review.get("candidate_version") == candidate.get("version"), "Review drift")
    require(
        review.get("candidate_sha256") == CANDIDATE_SHA256,
        "Review is not bound to the frozen candidate",
    )
    reviewer = review.get("reviewer", {})
    require(
        reviewer.get("name") == "Ugo Chukwu"
        and reviewer.get("role") == "project owner"
        and reviewer.get("date") == "2026-09-01"
        and reviewer.get("independent_of_authoring") is True
        and reviewer.get("qualified_domain_review") is False,
        "Unexpected reviewer identity or qualification claim",
    )
    require(
        review.get("scope") == "research_contract_review_not_production_approval",
        "Wrong review scope",
    )
    require(
        review.get("alignment_dataset_preparation_authorized") is True
        and review.get("training_authorized") is False
        and review.get("gpu_training_authorized") is False
        and review.get("production_authorized") is False,
        "Approval boundary changed",
    )
    decisions = review.get("records")
    require(
        isinstance(decisions, list)
        and [row.get("id") for row in decisions] == RECORD_IDS,
        "Review does not cover the exact ordered records",
    )
    fields = (
        "facts_supported",
        "tier_accepted",
        "pattern_accepted",
        "action_accepted",
        "rationale_accepted",
    )
    for row in decisions:
        require(
            row.get("decision") == "accepted_for_research_contract"
            and all(row.get(field) is True for field in fields),
            f"Unaccepted research-contract record: {row.get('id')}",
        )
    return review


def validate_data(data, evaluator):
    require(
        set(data)
        == {
            "schema_version",
            "version",
            "purpose",
            "split",
            "source_candidate_sha256",
            "source_review_sha256",
            "evaluator_sha256",
            "independent_confirmation_set",
            "records",
        },
        "Unexpected alignment-data fields",
    )
    require(data["schema_version"] == VERSION, "Wrong alignment schema version")
    require(data["version"] == DATA_VERSION, "Wrong alignment data version")
    require(
        data["purpose"] == "bounded_one_optimizer_step_interface_integration",
        "Wrong experiment purpose",
    )
    require(data["split"] == "development_only", "Data is not development-only")
    require(
        data["source_candidate_sha256"] == CANDIDATE_SHA256
        and data["source_review_sha256"] == REVIEW_SHA256
        and data["evaluator_sha256"] == EVALUATOR_SHA256,
        "Alignment provenance changed",
    )
    require(
        data["independent_confirmation_set"] is False,
        "Development data cannot be called independent confirmation",
    )
    records = data["records"]
    require(
        isinstance(records, list) and [row.get("id") for row in records] == RECORD_IDS,
        "Expected 15 exact ordered development records",
    )
    token_inputs = set()
    for row in records:
        require(
            set(row) == {"id", "source_group", "review_scope", "messages"},
            "Unexpected alignment record fields",
        )
        require(
            row["review_scope"] == "project_owner_research_contract_acceptance",
            "Wrong record review scope",
        )
        require(
            isinstance(row["source_group"], str)
            and row["source_group"].startswith("authored-"),
            "Wrong synthetic provenance",
        )
        messages = row["messages"]
        require(
            isinstance(messages, list)
            and [message.get("role") for message in messages] == ["user", "assistant"],
            "Expected one user/assistant pair",
        )
        require(
            all(
                set(message) == {"role", "content"}
                and isinstance(message["content"], str)
                and message["content"]
                for message in messages
            ),
            "Invalid messages",
        )
        require(
            not any(
                re.search(r"<\|[^\n]*?\|>", message["content"]) for message in messages
            ),
            "Control token in messages",
        )
        parsed = evaluator.parse_risk(messages[1]["content"])
        require(
            parsed is not None
            and parsed == evaluator.strict_json(messages[1]["content"]),
            "Assistant target is not canonical risk JSON",
        )
        token_key = canonical_hash(messages)
        require(token_key not in token_inputs, "Duplicate messages")
        token_inputs.add(token_key)
    return records


def feature_rows(data, tokenizer, evaluator):
    records = validate_data(data, evaluator)
    evaluator.validate_chat_tokenizer(tokenizer)
    features, references, details = [], {}, []
    for row in records:
        prompt = evaluator.render_chat(tokenizer, row["messages"][0]["content"])
        prompt_ids = tokenizer(prompt, add_special_tokens=False)["input_ids"]
        input_ids = tokenizer.apply_chat_template(
            row["messages"],
            tokenize=True,
            return_dict=False,
            add_generation_prompt=False,
            date_string=CHAT_DATE,
        )
        require(input_ids[: len(prompt_ids)] == prompt_ids, "Mask boundary mismatch")
        require(
            0 < len(prompt_ids) < len(input_ids) <= MAX_LENGTH,
            "Empty completion or sequence overflow",
        )
        require(
            input_ids.count(128000) == 1
            and input_ids[-1] == 128009
            and 128009 not in input_ids[len(prompt_ids) : -1],
            "Native BOS/EOS contract changed",
        )
        answer = input_ids[len(prompt_ids) :]
        require(
            tokenizer.decode(answer[:-1], skip_special_tokens=False)
            == row["messages"][1]["content"],
            "Target token decoding changed",
        )
        completion_mask = [0] * len(prompt_ids) + [1] * len(answer)
        labels = [-100] * len(prompt_ids) + answer
        identity = canonical_hash(input_ids)
        require(identity not in references, "Duplicate tokenized sequence")
        references[identity] = {
            "id": row["id"],
            "input_ids": input_ids,
            "labels": labels,
        }
        features.append({"input_ids": input_ids, "completion_mask": completion_mask})
        details.append(
            {
                "id": row["id"],
                "prompt_tokens": len(prompt_ids),
                "completion_tokens_including_eos": len(answer),
                "total_tokens": len(input_ids),
                "supervised_tokens": len(answer),
                "input_ids_sha256": identity,
                "labels_sha256": canonical_hash(labels),
            }
        )
    return features, references, details


def expected_token_checks(data, tokenizer, evaluator):
    _features, _references, details = feature_rows(data, tokenizer, evaluator)
    return {
        "schema_version": VERSION,
        "data_sha256": canonical_hash(data),
        "base_model": BASE_MODEL,
        "base_revision": BASE_REVISION,
        "chat_date": CHAT_DATE,
        "tokenizer_files": TOKENIZER_HASHES,
        "records": details,
        "rows": len(details),
        "max_total_tokens": max(row["total_tokens"] for row in details),
        "total_supervised_tokens": sum(row["supervised_tokens"] for row in details),
        "batch_size": EXPECTED_BATCH_SIZE,
        "gradient_accumulation_steps": EXPECTED_GRADIENT_ACCUMULATION,
        "expected_microbatches": EXPECTED_MICROBATCHES,
        "expected_optimizer_steps": EXPECTED_OPTIMIZER_STEPS,
        "packing": False,
        "padding_free": False,
        "completion_only_loss": True,
    }


def verify_token_checks(data, checks, tokenizer, evaluator):
    expected = expected_token_checks(data, tokenizer, evaluator)
    require(checks == expected, "Tokenizer or explicit-mask checks changed")
    return expected


def verify_batch(batch, references, pad_id):
    require(
        set(batch) == {"input_ids", "labels", "attention_mask"},
        "Unexpected batch keys; packing/padding-free is forbidden",
    )
    size = len(batch["input_ids"])
    require(size > 0, "Empty collated batch")
    require(
        len(batch["labels"]) == len(batch["attention_mask"]) == size,
        "Unequal batch dimensions",
    )
    widths = {len(row) for rows in batch.values() for row in rows}
    require(len(widths) == 1, "Ragged batch")
    matched = []
    for input_ids, labels, attention in zip(
        batch["input_ids"], batch["labels"], batch["attention_mask"]
    ):
        require(
            all(type(value) is int and value in (0, 1) for value in attention),
            "Invalid attention mask",
        )
        length = sum(attention)
        require(
            length > 0 and attention == [1] * length + [0] * (len(input_ids) - length),
            "Unexpected left/interior padding",
        )
        identity = canonical_hash(input_ids[:length])
        require(identity in references, "Unknown or truncated input row")
        reference = references[identity]
        require(
            labels == reference["labels"] + [-100] * (len(input_ids) - length),
            "Actual labels differ from explicit answer-only reference",
        )
        require(
            all(value == pad_id for value in input_ids[length:]),
            "Unexpected padding token",
        )
        require(labels[length - 1] == 128009, "Real completion EOS is masked")
        matched.append(reference["id"])
    return matched
