"""Prospective candidate recipe; frozen package hashes bind these exact bytes."""

import hashlib
import json
from pathlib import Path

from eval.v4 import domain_eval as runtime
from inference.native_predictor import prepare_training_example
from train.alignment_integration.contract import TOKENIZER_HASHES
from train.release_candidate.gates import GATES, SAMPLE_RATIONALE, SELECTION
from train.release_candidate.validate import validate_records

VERSION = "three-capability-candidate.1"
BASE_MODEL = runtime.BASE_MODEL
BASE_REVISION = runtime.BASE_REVISION
PINS = runtime.PINS
TRAIN_ROWS = 1900
EVALUATIONS = 490
STEPS = 238
WORKER_SECONDS = 21000
SESSION_SECONDS = 21600
OUTPUT_NAME = "Llama-3.1-8B-IOS-Risk-RC1"
RECIPE = {
    "optimizer_steps": STEPS,
    "batch_size": 2,
    "gradient_accumulation": 8,
    "learning_rate": 1e-4,
    "scheduler": "constant",
    "warmup_steps": 0,
    "weight_decay": 0.0,
    "optimizer": "adamw_8bit",
    "seed": 42,
    "lora_rank": 16,
    "lora_alpha": 16,
    "lora_dropout": 0.0,
    "packing": False,
    "padding_free": False,
    "padding": "right",
    "supervision": "explicit labels: prompt and padding -100; target including EOS supervised",
    "max_context": 2048,
    "expected_trainable_parameters": 41943040,
    "selection": SELECTION,
    "gates": GATES,
    "sample_rationale": SAMPLE_RATIONALE,
    "tokenizer_files": TOKENIZER_HASHES,
}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_data(path):
    data = json.loads(Path(path).read_text())
    rows = data["records"]
    validation = validate_records(
        rows, exposed_families=[], exposed_source_groups=[], exposed_inputs=[]
    )
    if validation["data_sha256"] != data["structural"]["data_sha256"]:
        raise ValueError("Canonical data identity changed")
    if (
        not data["exposure"]["automated_exclusion_passed"]
        or data["exposure"]["collisions"]
    ):
        raise ValueError("Historical exposure exclusions did not pass")
    train = [r for r in rows if r["split"] == "train"]
    evaluation = [r for r in rows if r["split"] != "train"] + data["familiar"]
    if len(train) != TRAIN_ROWS or len(evaluation) != EVALUATIONS:
        raise ValueError("Unexpected recipe row counts")
    ids = [r["id"] for r in rows + data["familiar"]]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate evaluation/training IDs")
    # Familiar questions deliberately reuse taught sections, but never prompts.
    prompts = [r["input"] for r in rows + data["familiar"]]
    if len(prompts) != len(set(prompts)):
        raise ValueError("Repeated familiar/training question")
    return data, train, evaluation


def token_checks(data, tokenizer):
    checks = {}
    for row in data["records"] + data["familiar"]:
        feature = prepare_training_example(tokenizer, row)
        checks[row["id"]] = {
            "prompt_ids_sha256": runtime.canonical_hash(
                feature["input_ids"][: feature["prompt_tokens"]]
            ),
            "input_ids_sha256": runtime.canonical_hash(feature["input_ids"]),
            "labels_sha256": runtime.canonical_hash(feature["labels"]),
            "length": len(feature["input_ids"]),
            "prompt_tokens": feature["prompt_tokens"],
        }
    return checks
