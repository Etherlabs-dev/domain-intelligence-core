"""Local preparation for the original three-capability model release."""
