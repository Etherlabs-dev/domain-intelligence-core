"""Recompute release metrics from raw outputs and hash-bound semantic reviews.

Semantic truth is never inferred from keyword presence. Until every risk and
regulatory output has a complete fact/source-grounded internal review, the
result is REVIEW_REQUIRED. Reviews are not independent professional validation.
"""

from collections import Counter
import hashlib
import json
import math
import random

from inference.native_predictor import risk_kwargs
from inference.native_protocol import validate_response
from train.release_candidate.gates import GATES


def content_hash(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, allow_nan=False).encode()
    ).hexdigest()


def rate(values):
    return sum(values) / len(values) if values else 0.0


def wilson(successes, n):
    """Descriptive binomial interval; source-cluster dependence is not removed."""
    if not n:
        return [0.0, 1.0]
    z = 1.959963984540054
    p = successes / n
    denominator = 1 + z * z / n
    middle = (p + z * z / (2 * n)) / denominator
    margin = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denominator
    return [max(0.0, middle - margin), min(1.0, middle + margin)]


def cluster_interval(rows, groups, metric, *, draws=2000):
    """Resample entire source groups, preserving all their correlated variants.

    This describes the observed benchmark's uncertainty, not population safety.
    A single observed group cannot estimate between-group variability.
    """
    clusters = {}
    for row in rows:
        clusters.setdefault(groups[row["id"]], []).append(row)
    keys = sorted(clusters)
    if len(keys) < 2:
        return {"clusters": len(keys), "interval95": None, "draws": 0}
    rng = random.Random(20260905)
    values = []
    for _ in range(draws):
        sample = [
            row for key in rng.choices(keys, k=len(keys)) for row in clusters[key]
        ]
        values.append(metric(sample))
    values.sort()
    return {
        "clusters": len(keys),
        "interval95": [values[int(draws * 0.025)], values[int(draws * 0.975) - 1]],
        "draws": draws,
        "seed": 20260905,
        "method": "whole_group_percentile_bootstrap",
    }


REVIEW_FIELDS = {
    "risk_assessment": {
        "rationale_supported",
        "evidence_relevant",
        "unsupported_claim",
        "contradiction_or_arithmetic_error",
        "unjustified_restriction",
    },
    "regulatory_identification": {"substantive_correct", "materially_false_rule"},
}


def validate_review(case, generation, review):
    if review is None:
        return None
    fields = REVIEW_FIELDS[case["task"]]
    if review.get("case_sha256") != content_hash(case) or review.get(
        "generation_sha256"
    ) != content_hash(generation):
        raise ValueError(
            "Semantic review is not bound to the exact case and raw output"
        )
    if set(review.get("judgments", {})) != fields:
        raise ValueError("Incomplete semantic review rubric")
    if any(type(v) is not bool for v in review["judgments"].values()):
        raise ValueError("Semantic judgments must be explicit booleans")
    if not isinstance(review.get("reason"), str) or not review["reason"].strip():
        raise ValueError("Fact/source-grounded review reason required")
    if (
        review.get("method") != "internal_ai_assisted"
        or review.get("qualified_independent_review") is not False
    ):
        raise ValueError("Unexpected review method or qualification claim")
    return review["judgments"]


def score_case(case, generation, review=None):
    check = validate_response(case["task"], generation, **risk_kwargs(case))
    valid = check["contract_valid"]
    result = {
        "id": case["id"],
        "task": case["task"],
        "valid": valid,
        "issues": check["issues"],
        "generation_sha256": content_hash(generation),
    }
    if case["task"] == "classification":
        result.update(
            expected=case["target"],
            predicted=check["answer"] if valid else "INVALID",
            correct=valid and check["answer"] == case["target"],
            review_complete=True,
        )
        return result
    judgment = validate_review(case, generation, review)
    result["review_complete"] = judgment is not None
    result["semantic_judgments"] = judgment
    if case["task"] == "risk_assessment":
        target = json.loads(case["target"])
        answer = check["answer"] or {}
        for field in ("tier", "pattern", "action"):
            result[field + "_correct"] = valid and answer.get(field) == target[field]
        evidence = answer.get("evidence", {})
        result["expected_tier"] = target["tier"]
        result["predicted_tier"] = answer.get("tier", "INVALID") if valid else "INVALID"
        result["required_abstention"] = target["tier"] == "UNDETERMINED"
        result["evidence_complete"] = valid and all(
            evidence.get(k) == v for k, v in target["evidence"].items()
        )
        result["full_answer_correct"] = bool(
            valid
            and all(result[f + "_correct"] for f in ("tier", "pattern", "action"))
            and result["evidence_complete"]
            and judgment
            and judgment["rationale_supported"]
            and judgment["evidence_relevant"]
            and not any(
                judgment[k]
                for k in (
                    "unsupported_claim",
                    "contradiction_or_arithmetic_error",
                    "unjustified_restriction",
                )
            )
        )
    else:
        target = validate_response(
            case["task"], {"text": case["target"], "finish_reason": "eos"}
        )["answer"]
        result["section"] = target["citations"][0]
        result["citation_correct"] = (
            valid and check["answer"]["citations"] == target["citations"]
        )
        result["substantive_correct"] = bool(
            valid
            and judgment
            and judgment["substantive_correct"]
            and not judgment["materially_false_rule"]
        )
        result["joint_correct"] = (
            result["citation_correct"] and result["substantive_correct"]
        )
    return result


def classification_metrics(rows):
    counts = Counter((r["expected"], r["predicted"]) for r in rows)
    tp = counts["FRAUD", "FRAUD"]
    fp = counts["LEGITIMATE", "FRAUD"]
    # Invalid answers to positive cases are missed fraud; do not drop them.
    fn = counts["FRAUD", "LEGITIMATE"] + counts["FRAUD", "INVALID"]
    precision, recall = (
        tp / (tp + fp) if tp + fp else 0,
        tp / (tp + fn) if tp + fn else 0,
    )
    return {
        "n": len(rows),
        "labels": dict(Counter(r["expected"] for r in rows)),
        "confusion_matrix": {
            label: {p: counts[label, p] for p in ("FRAUD", "LEGITIMATE", "INVALID")}
            for label in ("FRAUD", "LEGITIMATE")
        },
        "precision": precision,
        "recall": recall,
        "f1": 2 * precision * recall / (precision + recall)
        if precision + recall
        else 0,
        "false_negative_rate": fn / (tp + fn) if tp + fn else 1,
        "validity": rate([r["valid"] for r in rows]),
        "false_negative_ids": [
            r["id"]
            for r in rows
            if r["expected"] == "FRAUD" and r["predicted"] != "FRAUD"
        ],
        "recall_wilson95_descriptive": wilson(tp, tp + fn),
    }


def aggregate(cases, generations, reviews=None, protocols=None, failure_reviews=None):
    reviews, protocols = reviews or {}, protocols or {}
    if len({r["id"] for r in cases}) != len(cases):
        raise ValueError("Duplicate case IDs")
    expected = {r["id"] for r in cases}
    if set(generations) != expected or not set(reviews) <= expected:
        raise ValueError(
            "Raw output/review identities do not match complete evaluation"
        )
    if set(protocols) - expected:
        raise ValueError("Unknown evaluation protocol case")
    scored = [score_case(c, generations[c["id"]], reviews.get(c["id"])) for c in cases]
    failure_reviews = failure_reviews or {}
    required_failure_reviews = set()
    for row in scored:
        if row["task"] == "classification":
            severe = row["expected"] == "FRAUD" and row["predicted"] != "FRAUD"
        else:
            judgments = row["semantic_judgments"] or {}
            severe = any(
                judgments.get(key, False)
                for key in (
                    "unsupported_claim",
                    "contradiction_or_arithmetic_error",
                    "unjustified_restriction",
                    "materially_false_rule",
                )
            )
        if severe:
            required_failure_reviews.add(row["id"])
    if not set(failure_reviews) <= required_failure_reviews:
        raise ValueError(
            "Failure review does not identify a flagged severe failure or false negative"
        )
    case_by_id = {c["id"]: c for c in cases}
    for case_id, review in failure_reviews.items():
        if (
            review.get("case_sha256") != content_hash(case_by_id[case_id])
            or review.get("generation_sha256") != content_hash(generations[case_id])
            or review.get("method") != "internal_ai_assisted"
            or review.get("qualified_independent_review") is not False
            or review.get("reviewed") is not True
            or any(
                not isinstance(review.get(key), str) or not review[key].strip()
                for key in ("cause", "implication")
            )
        ):
            raise ValueError(
                "Failure review must bind exact evidence and explain cause and implication"
            )
    classification = classification_metrics(
        [r for r in scored if r["task"] == "classification"]
    )
    source_groups = {c["id"]: c["source_group"] for c in cases}
    families = {c["id"]: c["family"] for c in cases}
    classification["f1_cluster_uncertainty"] = cluster_interval(
        [r for r in scored if r["task"] == "classification"],
        source_groups,
        lambda sample: classification_metrics(sample)["f1"],
    )
    risk = [r for r in scored if r["task"] == "risk_assessment"]
    risk_metrics = {
        "n": len(risk),
        "validity": rate([r["valid"] for r in risk]),
        "tiers": dict(Counter(r["expected_tier"] for r in risk)),
    }
    for field in ("tier", "pattern", "action", "full_answer"):
        risk_metrics[field + "_accuracy"] = rate([r[field + "_correct"] for r in risk])
    risk_metrics["full_answer_cluster_uncertainty"] = cluster_interval(
        risk,
        families,
        lambda sample: rate([r["full_answer_correct"] for r in sample]),
    )
    risk_metrics["per_tier_accuracy"] = {
        tier: rate([r["tier_correct"] for r in risk if r["expected_tier"] == tier])
        for tier in sorted(risk_metrics["tiers"])
    }
    abstention = [r for r in risk if r["required_abstention"]]
    risk_metrics["required_abstention_cases"] = len(abstention)
    risk_metrics["required_abstention_accuracy"] = rate(
        [r["tier_correct"] for r in abstention]
    )
    for flag in (
        "unsupported_claim",
        "contradiction_or_arithmetic_error",
        "unjustified_restriction",
    ):
        risk_metrics[flag + "_rate"] = (
            rate([r["semantic_judgments"][flag] for r in risk])
            if all(r["review_complete"] for r in risk)
            else None
        )
    regulatory = {}
    for bucket in ("regulatory_familiar", "regulatory_transfer"):
        rows = [
            r
            for r in scored
            if r["task"] == "regulatory_identification"
            and protocols.get(r["id"]) == bucket
        ]
        regulatory[bucket] = {
            "n": len(rows),
            "sections": sorted({r["section"] for r in rows}),
            "validity": rate([r["valid"] for r in rows]),
            "materially_false_rule_rate": rate(
                [r["semantic_judgments"]["materially_false_rule"] for r in rows]
            )
            if all(r["review_complete"] for r in rows)
            else None,
        }
        for key in ("citation", "substantive", "joint"):
            regulatory[bucket][key + "_accuracy"] = rate(
                [r[key + "_correct"] for r in rows]
            )
        regulatory[bucket]["joint_cluster_uncertainty"] = cluster_interval(
            rows,
            {r["id"]: r["section"] for r in rows},
            lambda sample: rate([r["joint_correct"] for r in sample]),
        )
    if any(
        r["task"] == "regulatory_identification"
        and protocols.get(r["id"]) not in regulatory
        for r in scored
    ):
        raise ValueError(
            "Every regulatory case needs a named familiar/transfer protocol"
        )
    return {
        "case_set_sha256": content_hash(sorted(cases, key=lambda c: c["id"])),
        "prompt_identities": {
            k: v.get("prompt_token_ids_sha256") for k, v in generations.items()
        },
        "classification": classification,
        "risk": risk_metrics,
        **regulatory,
        "review_complete": all(r["review_complete"] for r in scored),
        "required_failure_review_ids": sorted(required_failure_reviews),
        "failure_reviews_complete": set(failure_reviews) == required_failure_reviews,
        "cases": scored,
        "source_groups": len({r["source_group"] for r in cases}),
        "scenario_families": len(
            {r["family"] for r in cases if r["task"] == "risk_assessment"}
        ),
        "qualified_independent_review": False,
    }


def decide(tuned, base):
    failures = []
    if tuned.get("case_set_sha256") != base.get("case_set_sha256"):
        raise ValueError("Base/tuned evaluation cases differ")
    if (
        not tuned.get("prompt_identities")
        or any(not p for p in tuned["prompt_identities"].values())
        or tuned["prompt_identities"] != base.get("prompt_identities")
    ):
        raise ValueError("Base/tuned actual prompt identities missing or different")
    if (
        not tuned["review_complete"]
        or not base["review_complete"]
        or not tuned.get("failure_reviews_complete")
        or not base.get("failure_reviews_complete")
    ):
        return {
            "status": "REVIEW_REQUIRED",
            "release_qualified": False,
            "failures": ["semantic_or_failure_reviews_incomplete"],
        }
    for bucket, gates in GATES.items():
        metrics = tuned[bucket]
        for key, threshold in gates.items():
            if key == "minimum_cases":
                passed = metrics["n"] >= threshold
            elif key == "minimum_per_label":
                passed = all(
                    metrics["labels"].get(label, 0) >= threshold
                    for label in ("FRAUD", "LEGITIMATE")
                )
            elif key == "minimum_per_tier":
                passed = all(
                    metrics["tiers"].get(tier, 0) >= threshold
                    for tier in ("LOW", "MEDIUM", "HIGH", "CRITICAL", "UNDETERMINED")
                )
            elif key == "minimum_sections":
                passed = len(metrics["sections"]) >= threshold
            elif key == "minimum_required_abstention_cases":
                passed = metrics["required_abstention_cases"] >= threshold
            elif key == "per_tier_accuracy_min":
                passed = all(
                    v >= threshold for v in metrics["per_tier_accuracy"].values()
                )
            elif key.endswith("_strictly_greater_than"):
                passed = metrics[key.removesuffix("_strictly_greater_than")] > threshold
            elif key.endswith("_min"):
                passed = metrics[key[:-4]] >= threshold
            elif key.endswith("_max"):
                passed = (
                    metrics[key[:-4]] is not None and metrics[key[:-4]] <= threshold
                )
            else:
                raise ValueError(f"Unknown gate: {key}")
            if not passed:
                failures.append(f"{bucket}.{key}")
    for bucket, metric in (
        ("classification", "f1"),
        ("risk", "full_answer_accuracy"),
        ("regulatory_familiar", "joint_accuracy"),
        ("regulatory_transfer", "joint_accuracy"),
    ):
        if tuned[bucket][metric] < base[bucket][metric]:
            failures.append(f"{bucket}.paired_nonregression")
    return {
        "status": "BENCHMARK_GATES_PASSED_REVIEW_RELEASE_EVIDENCE"
        if not failures
        else "BENCHMARK_GATES_FAILED",
        "release_qualified": not failures,
        "failures": failures,
        "publication_authorized": False,
        "production_authorized": False,
    }
