"""Offline result verification and scoring; raw evidence is never rewritten."""

import argparse
import json
import math
from pathlib import Path

from eval.v4.domain_eval import canonical_hash
from inference.native_protocol import VERSION as PROTOCOL
from inference.native_predictor import validate_adapter_manifest
from train.release_candidate import contract
from train.release_candidate.runner import preflight, require
from train.release_candidate.scoring import aggregate, decide


def read_lines(path):
    return [
        json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()
    ]


def verify_raw(cases, records, checks):
    expected = {row["id"]: row for row in cases}
    actual = {row["id"]: row for row in records}
    require(
        len(actual) == len(records) and set(actual) == set(expected),
        "Raw case identities incomplete or repeated",
    )
    generations = {}
    for identity, record in actual.items():
        require(
            record["case_sha256"] == canonical_hash(expected[identity]),
            "Raw output attached to different case",
        )
        require(
            record["protocol"] == PROTOCOL
            and record["task"] == expected[identity]["task"],
            "Raw protocol/task mismatch",
        )
        prompt_hash = canonical_hash(record["prompt_token_ids"])
        require(
            prompt_hash
            == checks[identity]["prompt_ids_sha256"]
            == record["generation"]["prompt_token_ids_sha256"],
            "Actual raw prompt IDs changed",
        )
        require(
            record["prompt_token_ids"].count(128000) == 1, "Actual prompt BOS differs"
        )
        generations[identity] = record["generation"]
    return generations


def verify(bundle, result, manifest_sha256, review_path=None):
    bundle, result = Path(bundle), Path(result)
    data, _, cases = preflight(bundle, manifest_sha256)
    supervisor = json.loads((result / "supervisor_receipt.json").read_text())
    require(
        supervisor["manifest_sha256"] == manifest_sha256
        and supervisor["completed"] is True
        and 0 < supervisor["session_seconds"] <= contract.SESSION_SECONDS
        and supervisor["session_ceiling"] == contract.SESSION_SECONDS,
        "Session supervision evidence missing or outside ceiling",
    )
    receipt = json.loads((result / "result_receipt.json").read_text())
    require(
        receipt["status"] == "CANDIDATE_GENERATIONS_COMPLETE_REVIEW_REQUIRED",
        "Incomplete worker result",
    )
    require(receipt["manifest_sha256"] == manifest_sha256, "Wrong run package")
    require(
        receipt["evaluations_per_model"] == contract.EVALUATIONS,
        "Wrong evaluation count",
    )
    require(
        0 < receipt["runtime_seconds"] <= contract.WORKER_SECONDS,
        "Worker runtime outside contract",
    )
    execution = json.loads((result / "preflight.json").read_text())
    require(
        execution["manifest_sha256"] == manifest_sha256 and execution["passed"] is True,
        "Missing runtime preflight",
    )
    require(
        execution["versions"] == contract.PINS
        and len(execution["gpu"]) == 2
        and all("T4" in name for name in execution["gpu"]),
        "GPU/dependency identity mismatch",
    )
    training = json.loads((result / "training_receipt.json").read_text())
    require(
        training["steps"] == contract.STEPS
        and math.isfinite(training["loss"])
        and training["loss"] > 0,
        "Training steps/loss invalid",
    )
    require(
        training["before_sha256"] != training["after_sha256"]
        and training["trainable_parameters"]
        == contract.RECIPE["expected_trainable_parameters"],
        "Training weight-change evidence invalid",
    )
    gradients = read_lines(result / "gradients.jsonl")
    require(
        [r["optimizer_step"] for r in gradients] == list(range(1, contract.STEPS + 1)),
        "Incomplete optimizer audit",
    )
    require(
        all(
            r["finite"] is True and math.isfinite(r["max_abs"]) and r["max_abs"] > 0
            for r in gradients
        ),
        "Invalid gradient evidence",
    )
    adapter = result / contract.OUTPUT_NAME
    native = validate_adapter_manifest(adapter)
    require(
        native["candidate_manifest_sha256"] == manifest_sha256,
        "Adapter belongs to another candidate",
    )
    weights = adapter / "adapter_model.safetensors"
    require(
        contract.digest(weights) == receipt["adapter_sha256"]
        and weights.stat().st_size == receipt["adapter_bytes"],
        "Adapter size/hash mismatch",
    )
    checks = json.loads((bundle / "token_checks.json").read_text())
    review = {} if review_path is None else json.loads(Path(review_path).read_text())
    release_cases = [c for c in cases if c["split"] != "development"]
    protocols = {
        c["id"]: "regulatory_familiar"
        if c["split"] == "familiar_section_paraphrase"
        else "regulatory_transfer"
        for c in release_cases
        if c["task"] == "regulatory_identification"
    }
    scores = {}
    for model in ("base", "tuned"):
        path = result / f"{model}-raw.jsonl"
        require(
            contract.digest(path) == receipt[f"{model}_raw_sha256"],
            "Raw output file hash mismatch",
        )
        generations = verify_raw(cases, read_lines(path), checks)
        selected = {c["id"]: generations[c["id"]] for c in release_cases}
        model_review = review.get(model, {})
        scores[model] = aggregate(
            release_cases,
            selected,
            model_review.get("semantic"),
            protocols,
            model_review.get("failures"),
        )
    return {
        "execution_verified": True,
        "manifest_sha256": manifest_sha256,
        "scores": scores,
        "decision": decide(scores["tuned"], scores["base"]),
        "development_cases_excluded_from_release_gates": len(cases)
        - len(release_cases),
        "historical_inventory_completeness_verified": False,
        "publication_authorized": False,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--reviews", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    value = verify(args.bundle, args.result, args.manifest_sha256, args.reviews)
    with args.out.open("x") as handle:
        json.dump(value, handle, indent=2, allow_nan=False)
        handle.write("\n")
    print(json.dumps(value["decision"], indent=2))
