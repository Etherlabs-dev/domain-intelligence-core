"""Prospective three-task data checks. No upload, CUDA, or release authority.

Labels and sources still require separate review. These structural checks do
not establish semantic independence, regulatory truth or model capability.
"""

from collections import Counter, defaultdict
import hashlib
import json
import re
import unicodedata

from inference.native_protocol import (
    ACTION_POLICY,
    TASKS,
    build_request,
    validate_response,
)


VERSION = "three-capability-release-data.1"
SPLITS = {"train", "development", "release_holdout"}
BASE_FIELDS = {"id", "task", "split", "family", "source_group", "input", "target"}


def fingerprint(text):
    normalized = " ".join(unicodedata.normalize("NFKC", text).casefold().split())
    return hashlib.sha256(normalized.encode()).hexdigest()


def validate_records(
    records, *, exposed_families, exposed_source_groups, exposed_inputs
):
    """Require all tasks in all splits and exclude exposed material from holdout.

    source_group means originating transaction/group for classification, scenario
    seed for risk, and source section+snapshot for regulatory examples. Regulatory
    section disjointness is a transfer test, not proof of learned unseen-rule recall.
    The caller must supply the complete historical exposure inventory; an empty
    inventory or fabricated source ID does not become verified by calling this.
    """
    if not isinstance(records, list) or not records:
        raise ValueError("Nonempty candidate data required")
    historical_families = set(exposed_families)
    historical_groups = set(exposed_source_groups)
    historical_inputs = {fingerprint(text) for text in exposed_inputs}
    seen_ids = set()
    families, sources, prompts, risk_shapes = (defaultdict(set) for _ in range(4))
    coverage = {split: Counter() for split in SPLITS}
    labels = {split: set() for split in SPLITS}
    tiers = {split: set() for split in SPLITS}
    sections = {split: set() for split in SPLITS}
    for row in records:
        if not isinstance(row, dict) or not BASE_FIELDS <= row.keys():
            raise ValueError("Missing record fields")
        task, split = row["task"], row["split"]
        if (
            not isinstance(task, str)
            or task not in TASKS
            or not isinstance(split, str)
            or split not in SPLITS
        ):
            raise ValueError("Unknown task/split")
        expected_fields = BASE_FIELDS | (
            {"facts", "relations"} if task == "risk_assessment" else set()
        )
        if set(row) != expected_fields:
            raise ValueError("Unexpected record metadata")
        for name in ("id", "family", "source_group", "input", "target"):
            if not isinstance(row[name], str) or not row[name].strip():
                raise ValueError(f"Nonempty {name} required")
        if row["id"] in seen_ids:
            raise ValueError("Duplicate record ID")
        seen_ids.add(row["id"])
        if split == "release_holdout" and (
            row["family"] in historical_families
            or row["source_group"] in historical_groups
            or fingerprint(row["input"]) in historical_inputs
        ):
            raise ValueError("Previously exposed material in release holdout")
        kwargs = (
            {"facts": row["facts"], "relations": row["relations"]}
            if task == "risk_assessment"
            else {}
        )
        build_request(task, row["input"], **kwargs)
        check = validate_response(
            task, {"text": row["target"], "finish_reason": "eos"}, **kwargs
        )
        if not check["contract_valid"]:
            raise ValueError(f"Invalid target for {row['id']}: {check['issues']}")
        if task == "regulatory_identification" and re.search(
            r"\b\d{4}\.\d{1,4}\b", row["input"]
        ):
            raise ValueError(
                "Citation-identification question supplies a section number"
            )
        if task == "risk_assessment":
            tiers[split].add(check["answer"]["tier"])
            # Sorting fact fields catches order changes; removing CaseReference
            # catches ID-only changes; numeric masking catches number-only variants.
            substantive = {
                k: v for k, v in row["facts"].items() if k != "CaseReference"
            }
            shape = re.sub(
                r"\d[\d,.]*", "<number>", json.dumps(substantive, sort_keys=True)
            )
            risk_shapes[fingerprint(shape)].add(split)
        elif task == "classification":
            labels[split].add(check["answer"])
        else:
            sections[split].update(check["answer"]["citations"])
        families[row["family"]].add(split)
        sources[row["source_group"]].add(split)
        key = fingerprint(row["input"])
        if key in prompts:
            raise ValueError("Duplicate prompt across candidate records")
        prompts[key].add(split)
        coverage[split][task] += 1
    for name, groups in (
        ("family", families),
        ("source", sources),
        ("risk shape", risk_shapes),
    ):
        if any(len(splits) > 1 for splits in groups.values()):
            raise ValueError(f"Cross-split {name} leakage")
    for split, counts in coverage.items():
        if set(counts) != TASKS:
            raise ValueError(
                f"All three tasks must appear in {split}; retention-only coverage is insufficient"
            )
        if labels[split] != {"FRAUD", "LEGITIMATE"}:
            raise ValueError(f"Both classification labels required in {split}")
        if tiers[split] != set(ACTION_POLICY):
            raise ValueError(f"All five risk tiers required in {split}")
        if len(sections[split]) < 2:
            raise ValueError(f"Multiple regulatory sections required in {split}")
    return {
        "schema_version": VERSION,
        "structural_checks_passed": True,
        "counts": {
            split: dict(sorted(counts.items()))
            for split, counts in sorted(coverage.items())
        },
        "data_sha256": hashlib.sha256(
            json.dumps(records, sort_keys=True, allow_nan=False).encode()
        ).hexdigest(),
        "semantic_review_complete": False,
        "historical_inventory_completeness_verified": False,
        "gpu_authorized": False,
        "model_ready": False,
    }
