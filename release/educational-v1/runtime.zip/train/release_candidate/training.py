"""Explicit native training features and an audited right-padding collator."""

from eval.v4.domain_eval import canonical_hash
from inference.native_predictor import prepare_training_example
from train.alignment_integration.contract import verify_batch


def feature_rows(rows, tokenizer):
    features, references = [], {}
    for row in rows:
        prepared = prepare_training_example(tokenizer, row)
        identity = canonical_hash(prepared["input_ids"])
        if identity in references:
            raise ValueError("Duplicate tokenized training example")
        references[identity] = {"id": row["id"], "labels": prepared["labels"]}
        features.append(
            {key: prepared[key] for key in ("input_ids", "attention_mask", "labels")}
        )
    return features, references


class AuditedCollator:
    """No packing or truncation; every real EOS remains supervised."""

    def __init__(self, pad_token_id, references):
        self.pad_token_id = pad_token_id
        self.references = references

    def lists(self, features):
        if not features:
            raise ValueError("Cannot collate an empty batch")
        width = max(len(row["input_ids"]) for row in features)
        batch = {key: [] for key in ("input_ids", "attention_mask", "labels")}
        for row in features:
            padding = width - len(row["input_ids"])
            batch["input_ids"].append(row["input_ids"] + [self.pad_token_id] * padding)
            batch["attention_mask"].append(row["attention_mask"] + [0] * padding)
            batch["labels"].append(row["labels"] + [-100] * padding)
        verify_batch(batch, self.references, self.pad_token_id)
        return batch

    def __call__(self, features):
        import torch

        return {
            key: torch.tensor(value, dtype=torch.long)
            for key, value in self.lists(features).items()
        }
