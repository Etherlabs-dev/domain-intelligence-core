"""Single candidate worker: audited training, clean reload and durable raw outputs.

No upload, publishing, automatic retry or automatic release decision is present.
The notebook supervisor enforces a hard wall-clock deadline outside this process.
"""

import argparse
from collections import Counter
import gc
import importlib.metadata
import json
import math
import os
from pathlib import Path
import time
import traceback

from eval.v4 import domain_eval as runtime
from inference.native_predictor import NativeRiskPredictor
from inference.native_protocol import VERSION as PROTOCOL
from train.alignment_pilot.runner import trainable_digest
from train.release_candidate import contract
from train.release_candidate.training import AuditedCollator, feature_rows
from train.alignment_integration.contract import verify_batch


def require(condition, message):
    if not condition:
        raise ValueError(message)


def save(path, value):
    with Path(path).open("x") as handle:
        json.dump(value, handle, indent=2, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())


def preflight(bundle, manifest_sha256):
    bundle = Path(bundle)
    require(
        contract.digest(bundle / "manifest.json") == manifest_sha256,
        "Wrong manifest identity",
    )
    manifest = json.loads((bundle / "manifest.json").read_text())
    actual_files = {
        str(p.relative_to(bundle)) for p in bundle.rglob("*") if p.is_file()
    }
    require(
        not actual_files
        - set(manifest["files"])
        - {"manifest.json", "dataset-metadata.json"},
        "Unexpected file in immutable candidate package",
    )
    for name, expected in manifest["files"].items():
        require(
            not Path(name).is_absolute() and ".." not in Path(name).parts,
            "Unsafe manifest path",
        )
        require(
            contract.digest(bundle / name) == expected, f"Changed package bytes: {name}"
        )
    require(
        manifest["recipe"] == contract.RECIPE, "Recipe differs from executing contract"
    )
    require(manifest["base_revision"] == contract.BASE_REVISION, "Base revision drift")
    return contract.load_data(bundle / "candidate_data.json")


def run(bundle, manifest_sha256, output):
    start = time.monotonic()
    data, training, evaluation = preflight(bundle, manifest_sha256)
    actual = {name: importlib.metadata.version(name) for name in contract.PINS}
    require(actual == contract.PINS, "Training dependency pins changed")
    from unsloth import FastLanguageModel
    import torch
    from datasets import Dataset
    from transformers import AutoTokenizer, TrainerCallback
    from transformers.utils.hub import cached_file
    from trl import SFTConfig, SFTTrainer

    require(torch.__version__.split("+")[0] == "2.10.0", "Wrong torch version")
    require(
        torch.cuda.is_available() and torch.cuda.device_count() == 2,
        "Exactly two visible T4 GPUs required",
    )
    names = [torch.cuda.get_device_name(i) for i in range(2)]
    require(all("T4" in name for name in names), "Wrong GPU model")
    torch.manual_seed(42)
    torch.cuda.manual_seed_all(42)
    tokenizer = AutoTokenizer.from_pretrained(
        contract.BASE_MODEL, revision=contract.BASE_REVISION, trust_remote_code=False
    )
    for name, expected in contract.TOKENIZER_HASHES.items():
        require(
            contract.digest(
                cached_file(contract.BASE_MODEL, name, revision=contract.BASE_REVISION)
            )
            == expected,
            "Tokenizer bytes changed",
        )
    tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"
    require(
        contract.token_checks(data, tokenizer)
        == json.loads((bundle / "token_checks.json").read_text()),
        "Token IDs or masks changed",
    )
    features, references = feature_rows(training, tokenizer)
    collator = AuditedCollator(tokenizer.pad_token_id, references)
    # All data, token identities and masks are checked before model loading.
    save(
        output / "preflight.json",
        {
            "passed": True,
            "manifest_sha256": manifest_sha256,
            "versions": actual,
            "gpu": names,
        },
    )
    model, unused_tokenizer = FastLanguageModel.from_pretrained(
        model_name=contract.BASE_MODEL,
        revision=contract.BASE_REVISION,
        max_seq_length=2048,
        load_in_4bit=True,
    )
    del unused_tokenizer
    model = FastLanguageModel.get_peft_model(
        model,
        r=16,
        target_modules=[
            "q_proj",
            "k_proj",
            "v_proj",
            "o_proj",
            "gate_proj",
            "up_proj",
            "down_proj",
        ],
        lora_alpha=16,
        lora_dropout=0,
        bias="none",
        use_gradient_checkpointing="unsloth",
        random_state=42,
    )
    require(
        all("lora_" in name for name, p in model.named_parameters() if p.requires_grad),
        "Non-LoRA weight is trainable",
    )
    before, count = trainable_digest(model)
    require(
        count == contract.RECIPE["expected_trainable_parameters"],
        "Unexpected trainable parameter count",
    )

    class Audit(TrainerCallback):
        calls = 0

        def on_log(self, args, state, control, logs=None, **kwargs):
            if logs and "loss" in logs:
                require(math.isfinite(logs["loss"]), "Nonfinite logged training loss")

        def on_pre_optimizer_step(self, args, state, control, model=None, **kwargs):
            gradients = [
                p.grad
                for p in model.parameters()
                if p.requires_grad and p.grad is not None
            ]
            require(
                gradients and all(torch.isfinite(g).all().item() for g in gradients),
                "Missing/nonfinite gradients",
            )
            maximum = max(float(g.detach().abs().max()) for g in gradients)
            require(maximum > 0, "Zero gradient optimizer step")
            self.calls += 1
            with (output / "gradients.jsonl").open("a") as handle:
                handle.write(
                    json.dumps(
                        {
                            "optimizer_step": self.calls,
                            "max_abs": maximum,
                            "finite": True,
                        }
                    )
                    + "\n"
                )
                handle.flush()
                os.fsync(handle.fileno())
            require(
                time.monotonic() - start < contract.WORKER_SECONDS,
                "Worker deadline reached",
            )

    audit = Audit()
    trainer = SFTTrainer(
        model=model,
        processing_class=tokenizer,
        train_dataset=Dataset.from_list(features),
        data_collator=collator,
        callbacks=[audit],
        args=SFTConfig(
            output_dir=str(output / "trainer-state"),
            max_steps=contract.STEPS,
            per_device_train_batch_size=2,
            gradient_accumulation_steps=8,
            learning_rate=1e-4,
            lr_scheduler_type="constant",
            warmup_steps=0,
            weight_decay=0.0,
            optim="adamw_8bit",
            logging_steps=1,
            save_strategy="no",
            report_to="none",
            seed=42,
            data_seed=42,
            packing=False,
            padding_free=False,
            max_length=2048,
            dataset_kwargs={"skip_prepare_dataset": True},
            remove_unused_columns=False,
            completion_only_loss=False,
            assistant_only_loss=False,
            dataloader_num_workers=0,
            dataloader_pin_memory=False,
            fp16=True,
            bf16=False,
        ),
    )
    require(
        trainer.args.world_size == 1 and trainer.args.train_batch_size == 2,
        "Effective batch contract requires one worker and two examples per microbatch",
    )
    verified = []
    for batch in trainer.get_train_dataloader():
        verified.extend(
            verify_batch(
                {k: v.cpu().tolist() for k, v in batch.items()},
                references,
                tokenizer.pad_token_id,
            )
        )
    require(
        Counter(verified) == Counter(r["id"] for r in training),
        "Actual trainer omitted or duplicated rows",
    )
    result = trainer.train()
    require(
        trainer.state.global_step == contract.STEPS == audit.calls,
        "Wrong optimizer-step count",
    )
    require(
        math.isfinite(result.training_loss) and result.training_loss > 0,
        "Invalid training loss",
    )
    after, after_count = trainable_digest(model)
    require(before != after and count == after_count, "LoRA weights did not change")
    adapter = output / contract.OUTPUT_NAME
    adapter.mkdir()
    model.save_pretrained(adapter)
    tokenizer.save_pretrained(adapter)
    require(
        (adapter / "adapter_model.safetensors").stat().st_size > 10_000_000,
        "Truncated adapter",
    )
    save(
        adapter / "native_manifest.json",
        {
            "protocol": PROTOCOL,
            "base_model": contract.BASE_MODEL,
            "base_revision": contract.BASE_REVISION,
            "candidate_manifest_sha256": manifest_sha256,
            "files": {
                name: contract.digest(adapter / name)
                for name in ("adapter_config.json", "adapter_model.safetensors")
            },
        },
    )
    save(
        output / "training_receipt.json",
        {
            "steps": audit.calls,
            "loss": result.training_loss,
            "trainable_parameters": count,
            "before_sha256": before,
            "after_sha256": after,
            "log_history": trainer.state.log_history,
            "training_seconds": time.monotonic() - start,
        },
    )
    del trainer, model
    gc.collect()
    torch.cuda.empty_cache()
    for label, adapter_path in (("base", None), ("tuned", adapter)):
        with (output / f"{label}-raw.jsonl").open("x") as handle:
            with NativeRiskPredictor.load(adapter_path) as predictor:
                for case in evaluation:
                    require(
                        time.monotonic() - start < contract.WORKER_SECONDS,
                        "Worker deadline reached",
                    )
                    record = predictor.generate(case)
                    record["case_sha256"] = runtime.canonical_hash(case)
                    handle.write(json.dumps(record, allow_nan=False) + "\n")
                    handle.flush()
                    os.fsync(handle.fileno())
    save(
        output / "result_receipt.json",
        {
            "status": "CANDIDATE_GENERATIONS_COMPLETE_REVIEW_REQUIRED",
            "manifest_sha256": manifest_sha256,
            "evaluations_per_model": len(evaluation),
            "runtime_seconds": time.monotonic() - start,
            "adapter_sha256": contract.digest(adapter / "adapter_model.safetensors"),
            "adapter_bytes": (adapter / "adapter_model.safetensors").stat().st_size,
            "base_raw_sha256": contract.digest(output / "base-raw.jsonl"),
            "tuned_raw_sha256": contract.digest(output / "tuned-raw.jsonl"),
            "release_qualified": False,
            "automatic_retry": False,
        },
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--run", action="store_true")
    args = parser.parse_args()
    if not args.run:
        preflight(args.bundle, args.manifest_sha256)
        print("CPU package checks passed; no model loaded")
        return
    require(args.output is not None, "A fresh output path is required")
    args.output.mkdir(parents=True, exist_ok=False)
    try:
        run(args.bundle, args.manifest_sha256, args.output)
    except BaseException:
        save(
            args.output / "failure_receipt.json",
            {"status": "FAILED_NO_RETRY", "traceback": traceback.format_exc()},
        )
        raise


if __name__ == "__main__":
    main()
