"""Prospective per-capability numerical gates, fixed before candidate outputs.

These are project benchmark acceptance criteria, not regulatory or production
standards. Sample sizes and source-family dependence must be reported with scores.
No aggregate can compensate for a failed capability; no output-based threshold
adjustment is permitted.
"""

VERSION = "three-capability-acceptance.1"
GATES = {
    "classification": {
        "minimum_cases": 200,
        "minimum_per_label": 100,
        "precision_min": 0.85,
        "recall_min": 0.90,
        "f1_min": 0.87,
        "false_negative_rate_max": 0.10,
        "validity_min": 0.99,
    },
    "risk": {
        "minimum_cases": 100,
        "minimum_per_tier": 20,
        "tier_accuracy_strictly_greater_than": 0.70,
        "per_tier_accuracy_min": 0.70,
        "pattern_accuracy_min": 0.80,
        "action_accuracy_min": 0.90,
        "full_answer_accuracy_min": 0.75,
        "validity_min": 0.98,
        "required_abstention_accuracy_min": 0.95,
        "minimum_required_abstention_cases": 20,
        "unsupported_claim_rate_max": 0.0,
        "contradiction_or_arithmetic_error_rate_max": 0.0,
        "unjustified_restriction_rate_max": 0.0,
    },
    "regulatory_familiar": {
        "minimum_cases": 40,
        "minimum_sections": 8,
        "citation_accuracy_min": 0.90,
        "substantive_accuracy_min": 0.85,
        "joint_accuracy_min": 0.85,
        "validity_min": 0.98,
        "materially_false_rule_rate_max": 0.0,
    },
    "regulatory_transfer": {
        "minimum_cases": 40,
        "minimum_sections": 8,
        "citation_accuracy_min": 0.80,
        "substantive_accuracy_min": 0.80,
        "joint_accuracy_min": 0.75,
        "validity_min": 0.98,
        "materially_false_rule_rate_max": 0.0,
    },
}

SELECTION = {
    "candidates": 1,
    "selection": "final adapter after the predeclared optimizer steps",
    "development": "diagnostic reporting only; no checkpoint or prompt selection",
    "release_holdout": "one paired base/tuned evaluation after adapter is fixed",
    "paired_nonregression": [
        "classification_f1",
        "risk_full_answer",
        "regulatory_joint_each_slice",
    ],
    "automatic_retry": False,
    "failed_candidate": "preserve outputs and analyze cause; new candidate needs new approval and new holdout",
}

SAMPLE_RATIONALE = (
    "200 balanced classification cases expose at least 100 fraud opportunities; "
    "one missed fraud changes recall by one percentage point. 100 risk cases give "
    "20 cases per tier; each per-tier error changes accuracy by five points. Each "
    "regulatory slice has 40 questions across at least eight sections. Questions "
    "sharing a source section or scenario family are correlated; report distinct "
    "family/group/section counts and cluster-aware uncertainty, and do not treat "
    "paraphrases as independent source draws. These are bounded project acceptance "
    "samples, not population safety estimates. Zero observed severe failures does "
    "not imply zero deployment risk. Larger naturally distributed validation is "
    "needed for production claims. Point thresholds are fixed engineering goals, "
    "not thresholds derived from expected candidate performance."
)
