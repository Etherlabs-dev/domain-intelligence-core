"""Prospective CPU request/response contract for the three-task release candidate.

This does not load a model, repair outputs, publish artifacts, or declare domain
correctness. The historical Alpaca predictor and evaluation remain unchanged.
All candidate training, evaluation and serving must call the same prompt builder.
"""

import json
import re

from eval.v4 import domain_eval as historical
from inference.numeric_consistency import input_issues, validate_relations


VERSION = "ios-risk-native-release-candidate.1"
TASKS = frozenset(historical.COUNTS)
ACTION_POLICY = {
    "LOW": "no_action",
    "MEDIUM": "review",
    "HIGH": "escalate",
    "CRITICAL": "restrict",
    "UNDETERMINED": "review",
}


def build_request(task, input_text, *, facts=None, relations=None):
    if task not in TASKS or not isinstance(input_text, str):
        raise ValueError("Known task and nonempty input required")
    if task != "risk_assessment" and not input_text.strip():
        raise ValueError("Nonempty input required")
    if re.search(r"<\|[^\n]*?\|>", input_text):
        raise ValueError("Native role/control tokens are not allowed in input")
    if task != "risk_assessment":
        if facts is not None or relations is not None:
            raise ValueError("Risk-only metadata supplied to another task")
        return historical.prompt_for({"task": task, "input": input_text})
    relations = [] if relations is None else relations
    validate_relations(facts, relations)
    for name, value in facts.items():
        if any(token in name + value for token in ("\n", "\r", "|", "<|")):
            raise ValueError("Ambiguous fact delimiter or role token")
    expected_input = " | ".join(f"{k}: {v}" for k, v in facts.items())
    if input_text != expected_input:
        raise ValueError("Prompt text and scoring facts differ")
    policy = (
        "Benchmark action mapping: LOW=no_action; MEDIUM=review; HIGH=escalate; "
        "CRITICAL=restrict; UNDETERMINED=review. These are proposed human-review "
        "labels, not authority to execute a financial action. Exclude CaseReference "
        "from evidence. For zero substantive facts, use empty evidence and abstain. "
        "The declared numeric relationships below refer only to their stated common "
        "population, window and unit. A violated relationship or invalid numeric "
        "value requires UNDETERMINED/undetermined/review, not a guessed decision. "
        "Do not infer relationships that are not supplied."
    )
    encoded = json.dumps(relations, ensure_ascii=False, sort_keys=True, allow_nan=False)
    if re.search(r"<\|[^\n]*?\|>", encoded):
        raise ValueError("Control token in relation metadata")
    return (
        historical.RISK_INSTRUCTION
        + "\n\n"
        + policy
        + "\n\nDeclared numeric relationships:\n"
        + encoded
        + "\n\nSupplied input:\n"
        + input_text
    )


def prepare_request(tokenizer, task, input_text, *, facts=None, relations=None):
    prompt = build_request(task, input_text, facts=facts, relations=relations)
    historical.validate_chat_tokenizer(tokenizer)
    rendered = historical.render_chat(tokenizer, prompt)
    ids = tokenizer.encode(rendered, add_special_tokens=False)
    if not ids or ids.count(historical.CONTROL_TOKENS["<|begin_of_text|>"]) != 1:
        raise ValueError("Expected exactly one native BOS token")
    if len(ids) + historical.LIMITS[task] > historical.MAX_CONTEXT:
        raise ValueError("Input plus output exceeds context; truncation forbidden")
    return {
        "protocol": VERSION,
        "task": task,
        "prompt": prompt,
        "rendered": rendered,
        "input_ids": ids,
        "max_new_tokens": historical.LIMITS[task],
    }


def validate_response(task, generation, *, facts=None, relations=None):
    """Structural/grounding checks only; valid output can still be a wrong answer."""
    if task not in TASKS or not isinstance(generation, dict):
        raise ValueError("Known task and generation record required")
    text = generation.get("text")
    if not isinstance(text, str):
        raise ValueError("Generation text must be a string")
    if task == "risk_assessment":
        relations = [] if relations is None else relations
        numeric_issues = input_issues(facts, relations)
    else:
        if facts is not None or relations is not None:
            raise ValueError("Risk metadata supplied to another task")
        numeric_issues = []
    issues, answer = [], None
    if generation.get("finish_reason") != "eos" or not text.strip():
        issues.append("incomplete_generation")
    invalid = historical.invalid_continuation(text, task)
    if invalid:
        issues.append(invalid)
    if task == "classification":
        if text.strip() not in {"FRAUD", "LEGITIMATE"}:
            issues.append("invalid_classification_label")
        else:
            answer = text.strip()
    elif task == "regulatory_identification":
        # A citation-format check cannot establish that a rule or explanation is true.
        citations = historical.CITATION.findall(text)
        if len(citations) != 1:
            issues.append("expected_exactly_one_citation")
        answer = {"text": text, "citations": citations}
    else:
        answer = historical.parse_risk(text)
        if answer is None:
            issues.append("invalid_risk_schema")
        else:
            original = historical.strict_json(text.strip())
            if original != answer:
                issues.append("noncanonical_risk_labels")
            substantive = {k: v for k, v in facts.items() if k != "CaseReference"}
            evidence = answer["evidence"]
            if len(evidence) < min(2, len(substantive)):
                issues.append("insufficient_evidence_fields")
            if any(
                k not in substantive or not v.strip() or substantive[k] != v
                for k, v in evidence.items()
            ):
                issues.append("ungrounded_evidence")
            if ACTION_POLICY[answer["tier"]] != answer["action"]:
                issues.append("tier_action_mismatch")
            abstains = (answer["tier"], answer["pattern"], answer["action"]) == (
                "UNDETERMINED",
                "undetermined",
                "review",
            )
            if (numeric_issues or not substantive) and not abstains:
                issues.append("failed_required_abstention")
            if answer["tier"] == "UNDETERMINED" and not abstains:
                issues.append("invalid_abstention_shape")
    return {
        "protocol": VERSION,
        "contract_valid": not issues,
        "issues": sorted(set(issues)),
        "numeric_input_issues": numeric_issues,
        "answer": answer,
        "domain_correctness": None,
        "human_review_required": True,
    }
