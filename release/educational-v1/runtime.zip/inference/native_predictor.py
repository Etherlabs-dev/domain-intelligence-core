"""Candidate native interface shared by training, evaluation and serving.

Loading stays explicit. CPU construction needs only a tokenizer. Historical
adapters are refused unless their manifest names this protocol and base revision.
The returned record retains raw output; invalid JSON is never repaired.
"""

from contextlib import contextmanager
import hashlib
import json
from pathlib import Path

from eval.v4 import domain_eval as runtime
from inference import native_protocol as protocol


def sha256(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def risk_kwargs(row):
    return (
        {"facts": row["facts"], "relations": row["relations"]}
        if row["task"] == "risk_assessment"
        else {}
    )


def prepare_training_example(tokenizer, row):
    prepared = protocol.prepare_request(
        tokenizer, row["task"], row["input"], **risk_kwargs(row)
    )
    target = row["target"]
    check = protocol.validate_response(
        row["task"], {"text": target, "finish_reason": "eos"}, **risk_kwargs(row)
    )
    if not check["contract_valid"] or "<|" in target:
        raise ValueError("Invalid training target or embedded control token")
    text = prepared["rendered"] + target + "<|eot_id|>"
    ids = tokenizer.encode(text, add_special_tokens=False)
    boundary = len(prepared["input_ids"])
    if ids[:boundary] != prepared["input_ids"]:
        raise ValueError("Training and serving prompt token IDs differ")
    if ids.count(128000) != 1 or ids[-1] != 128009 or 128009 in ids[boundary:-1]:
        raise ValueError("Expected one BOS and one terminal target EOS")
    if (
        len(ids) > runtime.MAX_CONTEXT
        or len(ids) - boundary > prepared["max_new_tokens"]
    ):
        raise ValueError(
            "Target exceeds training/inference budget; truncation forbidden"
        )
    if boundary >= len(ids) - 1:
        raise ValueError("Empty supervised answer")
    return {
        "id": row["id"],
        "input_ids": ids,
        "attention_mask": [1] * len(ids),
        "completion_mask": [0] * boundary + [1] * (len(ids) - boundary),
        "labels": [-100] * boundary + ids[boundary:],
        "prompt_tokens": boundary,
    }


def validate_adapter_manifest(adapter):
    adapter = Path(adapter)
    manifest = json.loads((adapter / "native_manifest.json").read_text())
    if (
        manifest.get("protocol") != protocol.VERSION
        or manifest.get("base_model") != runtime.BASE_MODEL
        or manifest.get("base_revision") != runtime.BASE_REVISION
    ):
        raise ValueError("Adapter has no matching frozen native contract")
    expected = {"adapter_config.json", "adapter_model.safetensors"}
    if set(manifest.get("files", {})) != expected:
        raise ValueError("Missing adapter identities")
    for name, expected_hash in manifest["files"].items():
        if sha256(adapter / name) != expected_hash:
            raise ValueError("Adapter bytes differ from native manifest")
    return manifest


class NativeRiskPredictor:
    """Wrap a live backend; `.load()` is the explicit CUDA/weight-loading boundary."""

    def __init__(self, backend):
        self.backend = backend

    @classmethod
    @contextmanager
    def load(cls, adapter=None):
        if adapter is not None:
            validate_adapter_manifest(adapter)
        backend = runtime.GPUBackend()
        with backend.session("tuned" if adapter is not None else "base", adapter):
            yield cls(backend)

    def generate(self, row):
        prepared = protocol.prepare_request(
            self.backend.tokenizer, row["task"], row["input"], **risk_kwargs(row)
        )
        generation = self.backend.generate(
            prepared["prompt"], prepared["max_new_tokens"], row["task"]
        )
        # The backend hashes its actual encoded tensor, after its own rendering.
        if generation.get("prompt_token_ids_sha256") != runtime.canonical_hash(
            prepared["input_ids"]
        ):
            raise ValueError("Actual inference prompt differs from training protocol")
        check = protocol.validate_response(row["task"], generation, **risk_kwargs(row))
        return {
            "id": row["id"],
            "task": row["task"],
            "protocol": protocol.VERSION,
            "prompt_token_ids": prepared["input_ids"],
            "generation": generation,
            "validation": check,
        }

    def assess_risk(self, facts, *, relations=None, request_id="request"):
        """Project 04 entry point: return raw output and explicit validation.

        Callers supply string-valued facts and declared relationships. An invalid
        response remains invalid; this method neither repairs it nor executes
        the suggested action.
        """
        return self.generate(
            {
                "id": request_id,
                "task": "risk_assessment",
                "input": " | ".join(f"{key}: {value}" for key, value in facts.items()),
                "facts": facts,
                "relations": [] if relations is None else relations,
            }
        )
