"""CPU-only checks for explicitly declared relationships, never inferred ones.

Constraints are part of the supplied input, not hidden expected answers. The
author must establish a common population, time window and unit. These checks
do not infer that Amount is a total or that two unrelated counts must match.
"""

from decimal import Decimal, localcontext
import re


class ConstraintError(ValueError):
    pass


ROLES = {
    "equal": {"left", "right"},
    "not_greater_than": {"part", "whole"},
    "observed_extrema_total": {"count", "minimum", "maximum", "total"},
}
UNITS = {"count", "USD", "units"}
NUMBER = re.compile(r"(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?\Z")


def validate_relations(facts, relations):
    if not isinstance(facts, dict) or not all(
        isinstance(k, str) and k and isinstance(v, str) and v.strip()
        for k, v in facts.items()
    ):
        raise ConstraintError("Facts must map nonempty names to nonempty strings")
    if not isinstance(relations, list) or len(relations) > 50:
        raise ConstraintError("Relations must be a bounded list")
    ids = set()
    for relation in relations:
        if not isinstance(relation, dict) or set(relation) != {
            "id",
            "kind",
            "fields",
            "unit",
            "scope",
        }:
            raise ConstraintError("Unknown or missing relation metadata")
        identifier = relation["id"]
        if (
            not isinstance(identifier, str)
            or not re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", identifier)
            or identifier in ids
        ):
            raise ConstraintError("Invalid or duplicate relation ID")
        ids.add(identifier)
        kind = relation["kind"]
        if not isinstance(kind, str) or kind not in ROLES:
            raise ConstraintError("Unsupported relation kind")
        fields = relation["fields"]
        if not isinstance(fields, dict) or set(fields) != ROLES[kind]:
            raise ConstraintError("Relation fields do not match its kind")
        if not all(isinstance(name, str) and name in facts for name in fields.values()):
            raise ConstraintError("Relation refers to an absent fact")
        if len(set(fields.values())) != len(fields):
            raise ConstraintError("Relation repeats the same field")
        unit = relation["unit"]
        if not isinstance(unit, str) or unit not in UNITS:
            raise ConstraintError("Unknown unit; no implicit currency conversion")
        scope = relation["scope"]
        if not isinstance(scope, str) or not scope.strip() or len(scope) > 500:
            raise ConstraintError("Explicit common population/window scope is required")


def _number(value, unit):
    if len(value) > 100 or value != value.strip():
        raise ConstraintError("Invalid numeric spelling")
    if value.startswith("$") and unit == "USD":
        value = value[1:]
    if NUMBER.fullmatch(value) is None:
        raise ConstraintError("Expected a nonnegative finite decimal")
    number = Decimal(value.replace(",", ""))
    if unit == "count" and number != number.to_integral_value():
        raise ConstraintError("A count must be integral")
    return number


def input_issues(facts, relations):
    """Return contradictions/invalid numbers; fail on malformed constraint metadata."""
    validate_relations(facts, relations)
    issues = []
    for relation in relations:
        identifier, kind = relation["id"], relation["kind"]
        try:
            values = {
                role: _number(
                    facts[field], "count" if role == "count" else relation["unit"]
                )
                for role, field in relation["fields"].items()
            }
        except ConstraintError:
            issues.append(f"invalid_number:{identifier}")
            continue
        # Exact decimal arithmetic, including large-but-bounded count x money.
        with localcontext() as ctx:
            ctx.prec = 250
            if kind == "equal":
                correct = values["left"] == values["right"]
            elif kind == "not_greater_than":
                correct = values["part"] <= values["whole"]
            else:
                n, low, high, total = (
                    values[k] for k in ("count", "minimum", "maximum", "total")
                )
                if n == 1:
                    correct = low == high == total
                else:
                    # Both extrema are declared observed, not merely bounds.
                    correct = (
                        n >= 2
                        and low <= high
                        and ((n - 1) * low + high <= total <= low + (n - 1) * high)
                    )
            if not correct:
                issues.append(f"contradiction:{identifier}")
    return issues
